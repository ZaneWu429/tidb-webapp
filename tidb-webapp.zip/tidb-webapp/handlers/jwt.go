// /tidb-webapp/handlers/jwt.go
package handlers

import (
    "fmt"
    "os"
    "time"
	"tidb-webapp/config"
    "github.com/golang-jwt/jwt/v5"
)


func getSecret() string {
    secret := os.Getenv("JWT_SECRET")
    if secret == "" {
        secret = "default_secret_please_change" // 开发用，生产请替换
    }
    return secret
}

// 生成 token
func GenerateJWT(userID uint, email, username string) (string, error) {
    token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
        "user_id": float64(userID),
        "email":   email,
        "username": username,
        "exp":     time.Now().Add(24 * time.Hour).Unix(), // 24小时过期
    })
    return token.SignedString(config.JwtSecret)
}

// 解析 token（供中间件使用）
func ParseJWT(tokenStr string) (jwt.MapClaims, error) {
    token, err := jwt.Parse(tokenStr, func(token *jwt.Token) (interface{}, error) {
        // 只接受 HMAC 签名方法
        if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
            return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
        }
        return config.JwtSecret, nil
    })

    if err != nil || !token.Valid {
        return nil, fmt.Errorf("invalid token: %v", err)
    }

    claims, ok := token.Claims.(jwt.MapClaims)
    if !ok {
        return nil, fmt.Errorf("invalid claims type")
    }

    // 验证必要字段
    if _, ok := claims["user_id"]; !ok {
        return nil, fmt.Errorf("missing user_id in token")
    }

    if _, ok := claims["username"]; !ok {
        return nil, fmt.Errorf("missing username in token")
    }
    
    if _, ok := claims["email"]; !ok {
        return nil, fmt.Errorf("missing email in token")
    }

    return claims, nil
}