CREATE OR REPLACE VIEW vuln_type_stats_view AS
SELECT
    year,

    /* 1. Overflow */
    SUM(CASE WHEN vuln_type = 'Overflow' THEN vuln_count ELSE 0 END)            AS Overflow,

    /* 2. Memory Corruption */
    SUM(CASE WHEN vuln_type = 'MemoryCorruption' THEN vuln_count ELSE 0 END)    AS MemoryCorruption,

    /* 3. SQL Injection */
    SUM(CASE WHEN vuln_type = 'SQLInjection' THEN vuln_count ELSE 0 END)        AS SQLInjection,

    /* 4. XSS */
    SUM(CASE WHEN vuln_type = 'XSS' THEN vuln_count ELSE 0 END)                 AS XSS,

    /* 5. Directory Traversal */
    SUM(CASE WHEN vuln_type = 'DirectoryTraversal' THEN vuln_count ELSE 0 END)  AS DirectoryTraversal,

    /* 6. File Inclusion */
    SUM(CASE WHEN vuln_type = 'FileInclusion' THEN vuln_count ELSE 0 END)       AS FileInclusion,

    /* 7. CSRF */
    SUM(CASE WHEN vuln_type = 'CSRF' THEN vuln_count ELSE 0 END)                AS CSRF,

    /* 8. XXE */
    SUM(CASE WHEN vuln_type = 'XXE' THEN vuln_count ELSE 0 END)                 AS XXE,

    /* 9. SSRF */
    SUM(CASE WHEN vuln_type = 'SSRF' THEN vuln_count ELSE 0 END)                AS SSRF,

    /* 10. Open Redirect */
    SUM(CASE WHEN vuln_type = 'OpenRedirect' THEN vuln_count ELSE 0 END)        AS OpenRedirect,

    /* 11. Input Validation */
    SUM(CASE WHEN vuln_type = 'InputValidation' THEN vuln_count ELSE 0 END)     AS InputValidation,

    /* 兜底：未匹配到任何以上类别的记录 */
    SUM(CASE WHEN vuln_type = 'Other' THEN vuln_count ELSE 0 END)               AS Other

FROM vuln_types_per_year
GROUP BY year
ORDER BY year ASC;
