-- -- 创建CVE分数段视图
-- CREATE OR REPLACE VIEW cve_severity_view AS
-- SELECT 
--     c.id AS cve_id,
--     c.published,
--     cp.vulnerable,
--     m.baseScore,
--     m.baseSeverity,
--     m.vectorString,
--     m.version AS cvss_version,
--     CASE
--         WHEN m.baseScore >= 9.0 THEN '9+'
--         WHEN m.baseScore >= 8.0 THEN '8-9'
--         WHEN m.baseScore >= 7.0 THEN '7-8'
--         WHEN m.baseScore >= 6.0 THEN '6-7'
--         WHEN m.baseScore >= 5.0 THEN '5-6'
--         WHEN m.baseScore >= 4.0 THEN '4-5'
--         WHEN m.baseScore >= 3.0 THEN '3-4'
--         WHEN m.baseScore >= 2.0 THEN '2-3'
--         WHEN m.baseScore >= 1.0 THEN '1-2'
--         ELSE '0-1'
--     END AS severity_range,
--     m.source AS score_source
-- FROM 
--     CVEEntry c
-- JOIN 
--     Metric m ON c.id = m.cve_id
-- JOIN
--     cpe_entries cp on cp.cve_id = c.id
-- ORDER BY 
--     m.baseScore DESC,
--     c.published DESC;

-- CREATE OR REPLACE VIEW cve_severity_view AS
-- WITH RankedMetrics AS (
--     SELECT 
--         c.id AS cve_id,
--         c.published,
--         cp.vulnerable,
--         m.baseScore,
--         m.baseSeverity,
--         m.vectorString,
--         m.version AS cvss_version,
--         m.source AS score_source,
--         ROW_NUMBER() OVER (PARTITION BY c.id ORDER BY m.baseScore DESC, m.cve_id DESC) AS rn
--     FROM 
--         CVEEntry c
--     JOIN 
--         Metric m ON c.id = m.cve_id
--     JOIN
--         cpe_entries cp ON cp.cve_id = c.id
-- )
-- SELECT 
--     cve_id,
--     published,
--     vulnerable,
--     baseScore,
--     baseSeverity,
--     vectorString,
--     cvss_version,
--     CASE
--         WHEN baseScore >= 9.0 THEN '9+'
--         WHEN baseScore >= 8.0 THEN '8-9'
--         WHEN baseScore >= 7.0 THEN '7-8'
--         WHEN baseScore >= 6.0 THEN '6-7'
--         WHEN baseScore >= 5.0 THEN '5-6'
--         WHEN baseScore >= 4.0 THEN '4-5'
--         WHEN baseScore >= 3.0 THEN '3-4'
--         WHEN baseScore >= 2.0 THEN '2-3'
--         WHEN baseScore >= 1.0 THEN '1-2'
--         ELSE '0-1'
--     END AS severity_range,
--     score_source
-- FROM 
--     RankedMetrics
-- WHERE 
--     rn = 1
-- ORDER BY 
--     baseScore DESC,
--     published DESC;

CREATE OR REPLACE VIEW cve_severity_view AS
SELECT 
    c.id AS cve_id,
    c.published,
    cp.vulnerable,
    m.baseScore,
    m.baseSeverity,
    m.vectorString,
    m.version AS cvss_version,
    m.source AS score_source,
    CASE
        WHEN m.baseScore >= 9.0 THEN '9+'
        WHEN m.baseScore >= 8.0 THEN '8-9'
        WHEN m.baseScore >= 7.0 THEN '7-8'
        WHEN m.baseScore >= 6.0 THEN '6-7'
        WHEN m.baseScore >= 5.0 THEN '5-6'
        WHEN m.baseScore >= 4.0 THEN '4-5'
        WHEN m.baseScore >= 3.0 THEN '3-4'
        WHEN m.baseScore >= 2.0 THEN '2-3'
        WHEN m.baseScore >= 1.0 THEN '1-2'
        ELSE '0-1'
    END AS severity_range
FROM 
    CVEEntry c
JOIN (
    SELECT 
        m.*,
        ROW_NUMBER() OVER (PARTITION BY m.cve_id ORDER BY m.baseScore DESC, m.cve_id DESC) AS rn
    FROM 
        Metric m
) m ON c.id = m.cve_id AND m.rn = 1
JOIN cpe_entries cp ON cp.cve_id = c.id
ORDER BY 
    m.baseScore DESC,
    c.published DESC;

-- ALTER TABLE Metric ADD INDEX idx_cve_score_id (cve_id, baseScore DESC);
-- ALTER TABLE CVEEntry ADD INDEX idx_published (published DESC);