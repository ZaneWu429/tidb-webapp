-- extra_features14_2.sql
-- 创建触发器
DELIMITER //
CREATE TRIGGER after_user_insert
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO user_audit_log (user_id, action)
    VALUES (NEW.id, 'User registered');
END//

DELIMITER ;