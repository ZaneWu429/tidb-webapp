INSERT INTO vuln_types_per_year (year, vuln_type, vuln_count)
SELECT 
    SUBSTRING(cve_id, 5, 4) AS year,
    CASE
        /* ―――― 1. Overflow ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(buffer (overflow|overrun)|stack overflow|heap overflow|integer overflow|overflow)([^a-z]|$)'
            THEN 'Overflow'

        /* ―――― 2. Memory Corruption ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(memory corruption|use[- ]after[- ]free|uaf|double free|out[- ]of[- ]bounds|oob (read|write)|dangling pointer|wild pointer)([^a-z]|$)'
            THEN 'MemoryCorruption'

        /* ―――― 3. SQL Injection ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(sql injection|sqli|blind sql|sql code injection|sql command injection)([^a-z]|$)'
            THEN 'SQLInjection'

        /* ―――― 4. XSS ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(cross[- ]site scripting|xss)([^a-z]|$)'
            THEN 'XSS'

        /* ―――― 5. Directory Traversal ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])((directory|path) traversal|\\.\\./|\\.\\.[\\\\/])([^a-z]|$)'
            THEN 'DirectoryTraversal'

        /* ―――― 6. File Inclusion ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(file inclusion|local file inclusion|lfi|remote file inclusion|rfi)([^a-z]|$)'
            THEN 'FileInclusion'

        /* ―――― 7. CSRF ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(cross[- ]site request forgery|csrf)([^a-z]|$)'
            THEN 'CSRF'

        /* ―――― 8. XXE ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(xml external entity|xxe|external entity injection)([^a-z]|$)'
            THEN 'XXE'

        /* ―――― 9. SSRF ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(server[- ]side request forgery|ssrf)([^a-z]|$)'
            THEN 'SSRF'

        /* ――――10. Open Redirect ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(open redirect|url redirect|unvalidated redirect|redirect vulnerability)([^a-z]|$)'
            THEN 'OpenRedirect'

        /* ――――11. Input Validation ―――― */
        WHEN LOWER(value) REGEXP '(^|[^a-z])(input validation|input sanitization|improper input validation|unsanitized input|lack of sanitization)([^a-z]|$)'
            THEN 'InputValidation'

        /* ―――― 兜底 ―――― */
        ELSE 'Other'
    END AS vuln_type,
    COUNT(*) AS vuln_count
FROM description
WHERE lang = 'en'
GROUP BY year, vuln_type;
