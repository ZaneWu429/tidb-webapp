// /tidb-webapp/handlers/product.go
package handlers

import (
	"fmt"
	"math"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"strings"
)

type ProductEntry struct {
	ProductName   string `json:"product"`
	VendorName    string `json:"vendor"`
	VulnCount     int    `json:"vulnerability_count"`
	ProductType   string `json:"part_type"`
}

type ProductResponse struct {
	Products    []ProductEntry `json:"products"`
	Total       int            `json:"total"`
	TotalPages  int            `json:"total_pages"`
}

func GetProducts(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
		limit := 20
		offset := (page - 1) * limit

		search := c.Query("search")
		letter := c.Query("letter")

		var condition string
		var args []interface{}

		if search != "" {
			condition = "product LIKE ?"
			args = append(args, "%"+search+"%")
		} else if letter != "" {
			condition = "product LIKE ?"
			args = append(args, letter+"%")
		} else {
			condition = "1=1"
		}

		countSQL := fmt.Sprintf(`
			SELECT COUNT(*) FROM (
				SELECT DISTINCT vendor, product
				FROM cpe_entries
				WHERE %s
			) AS sub
		`, condition)

		var total int
		if err := db.Raw(countSQL, args...).Row().Scan(&total); err != nil {
			c.JSON(500, gin.H{"error": "count error"})
			return
		}

		dataSQL := fmt.Sprintf(`
			SELECT 
				CASE part
					WHEN 'a' THEN 'Application'
					WHEN 'o' THEN 'Operating System'
					WHEN 'h' THEN 'Hardware'
					ELSE 'Unknown'
				END AS part_type,
				vendor, product,
				COUNT(DISTINCT cve_id) AS vulnerability_count
			FROM cpe_entries
			WHERE %s
			GROUP BY part_type, vendor, product
			ORDER BY product
			LIMIT ? OFFSET ?`, condition)

		argsWithPage := append(args, limit, offset)
		rows, err := db.Raw(dataSQL, argsWithPage...).Rows()
		if err != nil {
			c.JSON(500, gin.H{"error": "query error"})
			return
		}
		defer rows.Close()

		var products []ProductEntry
		for rows.Next() {
			var p ProductEntry
			if err := rows.Scan(&p.ProductType, &p.VendorName, &p.ProductName, &p.VulnCount); err == nil {
				products = append(products, p)
			}
		}

		c.JSON(200, ProductResponse{
			Products:    products,
			Total:       total,
			TotalPages:  int(math.Ceil(float64(total) / float64(limit))),
		})
	}
}

func ProductSuggest(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		keyword := c.Query("keyword")
		if keyword == "" {
			c.JSON(http.StatusOK, gin.H{"suggestions": []string{}})
			return
		}

		var suggestions []string
		err := db.Raw(`
			SELECT DISTINCT product 
			FROM cpe_entries 
			WHERE LOWER(TRIM(product)) LIKE LOWER(?) 
			ORDER BY product 
			LIMIT 10
		`, keyword+"%").Scan(&suggestions).Error

		if err != nil {
			c.JSON(500, gin.H{"error": "suggest query error"})
			return
		}

		c.JSON(200, gin.H{"suggestions": suggestions})
	}
}

// GET /api/vendors/:vendor/products?page=1&search=http
func GetProductsByVendor(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		vendor := c.Param("vendor")                    // URL 中的原始字符串（已做 URLDecode）
		search := c.Query("search")                    // 可选搜索
		page, _ := strconv.Atoi(c.DefaultQuery("page","1"))
		limit := 20
		offset := (page-1)*limit

		condition := "vendor = ?"
		args      := []interface{}{vendor}

		if search != "" {
			condition += " AND LOWER(product) LIKE ?"
			args = append(args, "%"+strings.ToLower(search)+"%")
		}

		// 计算总数
		var total int
		countSQL := fmt.Sprintf(`SELECT COUNT(DISTINCT product) FROM cpe_entries WHERE %s`, condition)
		if err := db.Raw(countSQL, args...).Row().Scan(&total); err != nil {
			c.JSON(500, gin.H{"error":"count error"})
			return
		}

		// 分页查询
		argsWithPage := append(args, limit, offset)
		rows, err := db.Raw(fmt.Sprintf(`
			SELECT vendor, product, COUNT(DISTINCT cve_id) AS vuln_count
			FROM cpe_entries
			WHERE %s
			GROUP BY product, vendor
			ORDER BY product
			LIMIT ? OFFSET ?`, condition), argsWithPage...).Rows()
		if err != nil {
			c.JSON(500, gin.H{"error":"query error"})
			return
		}
		defer rows.Close()

		var list []ProductEntry
		for rows.Next() {
			var p ProductEntry
			if err := rows.Scan(&p.VendorName, &p.ProductName, &p.VulnCount); err == nil {
				list = append(list, p)
			}
		}

		c.JSON(200, ProductResponse{
			Products:   list,
			Total:      total,
			TotalPages: int(math.Ceil(float64(total)/float64(limit))),
		})
	}
}

func GetProductVulnerabilities(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        vendor := c.Query("vendor")
        product := c.Query("product")

        // 检查参数是否为空
        if vendor == "" || product == "" {
            c.JSON(http.StatusBadRequest, gin.H{"error": "vendor and product are required"})
            return
        }

        var cveIds []string

        // 查询数据库，获取指定 vendor 和 product 的所有 CVE 编号
        err := db.Raw(`
            SELECT DISTINCT cve_id 
            FROM cpe_entries 
            WHERE LOWER(vendor) = ? AND LOWER(product) = ?
            ORDER BY cve_id
        `, strings.ToLower(vendor), strings.ToLower(product)).Scan(&cveIds).Error

        if err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": "query error"})
            return
        }

        // 返回结果
        c.JSON(http.StatusOK, gin.H{
            "vendor":   vendor,
            "product":  product,
            "cve_ids":  cveIds,
        })
    }
}