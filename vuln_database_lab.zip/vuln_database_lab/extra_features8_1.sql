-- 必须在执行cpe.py之前执行这个sql代码

CREATE TABLE IF NOT EXISTS cpe_entries (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    cve_id VARCHAR(100),
    vulnerable BOOLEAN,
    part VARCHAR(10),
    vendor VARCHAR(255),
    product VARCHAR(255),
    version VARCHAR(100),
    update_version VARCHAR(100),
    edition VARCHAR(100),
    language VARCHAR(100),
    sw_edition VARCHAR(100),
    target_sw VARCHAR(100),
    target_hw VARCHAR(100),
    other VARCHAR(100)
);
