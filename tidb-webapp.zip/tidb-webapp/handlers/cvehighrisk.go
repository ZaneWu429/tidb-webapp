// /tidb-webapp/handlers/cvehighrisk.go
package handlers

import (
    "net/http"
    "strconv"

    "github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type CVEHighriskSummary struct {
    CVEID       string  `json:"id"`
    Description string  `json:"description"`
    Published   string  `json:"published"`
    BaseScore   float64 `json:"base_score"`
}

func NewHighBaseScoreHandler(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        pageStr := c.DefaultQuery("page", "1")
        pageSizeStr := c.DefaultQuery("size", "20")

        page, err := strconv.Atoi(pageStr)
        if err != nil || page < 1 {
            page = 1
        }
        size, err := strconv.Atoi(pageSizeStr)
        if err != nil || size < 1 || size > 100 {
            size = 20
        }

        offset := (page - 1) * size
		// 查询总数SQL（注意只计算总数，不取数据）
        countSQL := `
        SELECT COUNT(*) 
        FROM metric m
        JOIN cveentry c ON m.cve_id = c.id
        JOIN description d ON m.cve_id = d.cve_id AND d.lang = 'en'
        WHERE m.baseScore > 9.0;
        `

        var total int64
        if err := db.Raw(countSQL).Scan(&total).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
            return
        }

        sqlQuery := `
        SELECT
            m.cve_id,
            d.value AS description,
            c.published,
            m.baseScore
        FROM
            metric m
        JOIN
            cveentry c ON m.cve_id = c.id
        JOIN
            description d ON m.cve_id = d.cve_id AND d.lang = 'en'
        WHERE
            m.baseScore > 9.0
        ORDER BY m.cve_id DESC
        LIMIT ? OFFSET ?;
        `

        var results []CVEHighriskSummary
        if err := db.Raw(sqlQuery, size, offset).Scan(&results).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
            return
        }

        c.JSON(http.StatusOK, gin.H{
            "page":     page,
            "size": 	size,
			"total": 	total,
            "data":     results,
        })
    }
}

