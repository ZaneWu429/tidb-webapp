// /tidb-webapp/handlers/version.go
package handlers

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func SearchVersionCVEHandler(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		vendor := c.DefaultQuery("vendor", "")
		product := c.DefaultQuery("product", "")
		version := c.DefaultQuery("version", "")

		// 统一把 "null" 当作空字符串处理
		if vendor == "null" {
			vendor = ""
		}
		if product == "null" {
			product = ""
		}
		if version == "null" {
			version = ""
		}

		// 至少一个字段非空
		if vendor == "" && product == "" && version == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "At least one of vendor, product, or version must be provided."})
			return
		}

		var queryBuilder strings.Builder
		var args []interface{}

		queryBuilder.WriteString("SELECT DISTINCT cve_id FROM cpe_entries WHERE 1=1")

		// 添加 vendor 条件
		if vendor != "" {
			if strings.HasPrefix(vendor, "*") {
				c.JSON(http.StatusBadRequest, gin.H{"error": "Wildcard '*' is not allowed at the beginning of vendor"})
				return
			}
			queryBuilder.WriteString(" AND LOWER(vendor) LIKE ?")
			args = append(args, strings.ToLower(convertWildcard(vendor)))
		}

		// 添加 product 条件
		if product != "" {
			if strings.HasPrefix(product, "*") {
				c.JSON(http.StatusBadRequest, gin.H{"error": "Wildcard '*' is not allowed at the beginning of product"})
				return
			}
			queryBuilder.WriteString(" AND LOWER(product) LIKE ?")
			args = append(args, strings.ToLower(convertWildcard(product)))
		}

		// 添加 version 条件
		if version != "" {
			if strings.HasPrefix(version, "*") {
				c.JSON(http.StatusBadRequest, gin.H{"error": "Wildcard '*' is not allowed at the beginning of version"})
				return
			}
			queryBuilder.WriteString(" AND version LIKE ?")
			args = append(args, convertWildcard(version))
		}

		var result []string
		if err := db.Raw(queryBuilder.String(), args...).Scan(&result).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		c.JSON(http.StatusOK, result)
	}
}

// 将用户传入的 * 替换为 SQL 的 %，用于模糊匹配
func convertWildcard(input string) string {
	return strings.ReplaceAll(input, "*", "%")
}
