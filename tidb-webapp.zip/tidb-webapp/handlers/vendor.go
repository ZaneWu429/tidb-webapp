// /tidb-webapp/handlers/vendor.go
package handlers

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"strconv"
	"math"
	"database/sql"
	"strings"
)
// VendorEntry 表结构
type VendorEntry struct {
	Vendor       string `json:"vendor"`
	ProductCount int    `json:"product_count"`
	VulnCount    int    `json:"vuln_count"`
}

type VendorResponse struct {
	Vendors     []VendorEntry `json:"vendors"`
	Total       int           `json:"total"`
	TotalPages  int           `json:"total_pages"`
}

// GET /api/vendors?letter=A&page=1 OR /api/vendors?search=apache&page=1
func GetVendors(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
		limit := 20
		offset := (page - 1) * limit

		search := c.Query("search")
		letter := c.Query("letter")

		var rows *sql.Rows
		var total int
		var err error

		base := `
			SELECT vendor, COUNT(DISTINCT product) as product_count, COUNT(DISTINCT cve_id) as vuln_count
			FROM cpe_entries
			WHERE %s
			GROUP BY vendor
			ORDER BY vendor
			LIMIT ? OFFSET ?`

		countSQL := `SELECT COUNT(DISTINCT vendor) FROM cpe_entries WHERE %s`

		var condition string
		var args []interface{}

		if search != "" {
			condition = "LOWER(vendor) LIKE ?"
			args = append(args, "%"+strings.ToLower(search)+"%")
		} else if letter != "" {
			condition = "LOWER(vendor) LIKE ?"
			args = append(args, strings.ToLower(letter)+"%")
		} else {
			condition = "1=1"
		}

		// 查询总数
		err = db.Raw(fmt.Sprintf(countSQL, condition), args...).Row().Scan(&total)
		if err != nil {
			c.JSON(500, gin.H{"error": "count error"})
			return
		}

		// 查询分页数据
		args = append(args, limit, offset)
		rows, err = db.Raw(fmt.Sprintf(base, condition), args...).Rows()
		if err != nil {
			c.JSON(500, gin.H{"error": "query error"})
			return
		}
		defer rows.Close()

		var results []VendorEntry
		for rows.Next() {
			var v VendorEntry
			if err := rows.Scan(&v.Vendor, &v.ProductCount, &v.VulnCount); err == nil {
				results = append(results, v)
			}
		}

		c.JSON(200, VendorResponse{
			Vendors:    results,
			Total:      total,
			TotalPages: int(math.Ceil(float64(total) / float64(limit))),
		})
	}
}


func VendorSuggest(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		keyword := strings.ToLower(strings.TrimSpace(c.Query("keyword")))
		if keyword == "" {
			c.JSON(400, gin.H{"error": "keyword is required"})
			return
		}

		var vendors []string

		err := db.Raw(`
			SELECT DISTINCT vendor 
			FROM cpe_entries 
			WHERE LOWER(TRIM(vendor)) LIKE ? 
			ORDER BY vendor 
			LIMIT 10
		`, keyword+"%").Scan(&vendors).Error

		if err != nil {
			c.JSON(500, gin.H{"error": "query error"})
			return
		}

		c.JSON(200, gin.H{"suggestions": vendors})
	}
}

type ProductWithPart struct {
    Product string `json:"product"`
    Part    string `json:"part"`
}

func GetVendorProducts(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        vendor := c.Param("vendor")

        // 定义切片存储查询结果
        var products []ProductWithPart

        // 修改 SQL 查询，同时获取 product 和 part 字段
        err := db.Raw(`
            SELECT DISTINCT product, part 
            FROM cpe_entries 
            WHERE LOWER(vendor) = ?
            ORDER BY product
        `, strings.ToLower(vendor)).Scan(&products).Error

        if err != nil {
            c.JSON(500, gin.H{"error": "query error"})
            return
        }

        // 返回结果
        c.JSON(200, gin.H{
            "vendor":   vendor,
            "products": products,
        })
    }
}

func GetVendorVulnerabilities(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        vendor := c.Param("vendor")

        var cveIds []string

        err := db.Raw(`
            SELECT DISTINCT cve_id 
            FROM cpe_entries 
            WHERE LOWER(vendor) = ?
            ORDER BY cve_id
        `, strings.ToLower(vendor)).Scan(&cveIds).Error

        if err != nil {
            c.JSON(500, gin.H{"error": "query error"})
            return
        }

        c.JSON(200, gin.H{
            "vendor":   vendor,
            "cve_ids":  cveIds,
        })
    }
}