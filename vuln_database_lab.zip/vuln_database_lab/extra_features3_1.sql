CREATE VIEW vuln_type_summary_view AS
SELECT 
    vuln_type,
    SUM(vuln_count) AS total_count,
    ROUND(SUM(vuln_count) * 100.0 / 
         (SELECT SUM(vuln_count) FROM vuln_stats_view WHERE vuln_type != 'Other'), 2) AS percentage
FROM 
    vuln_stats_view
WHERE 
    vuln_type != 'Other'
GROUP BY 
    vuln_type
ORDER BY 
    total_count DESC;
