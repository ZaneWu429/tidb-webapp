// tidb-webapp/main.go
package main

import (
	"net/http"
	"tidb-webapp/models"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
    "tidb-webapp/handlers"
    "tidb-webapp/config"
    "time"
    "log"
    "tidb-webapp/auth"
    // "os"
    "tidb-webapp/dbadmin"
	// "sort"
)

var (
    db *gorm.DB
)

func main() {
	// 初始化数据库连接
	dsn := "root:@tcp(127.0.0.1:4000)/cve_db?charset=utf8mb4&parseTime=True&loc=Local"
	var err error
	db, err = models.InitDB(dsn)
	if err != nil { log.Fatalf("DB err: %v", err) }
    
    //jwtSecret := []byte("replace-with-32-random-bytes") // put in env var for prod
	ah := auth.New(db, config.JwtSecret)

    
	// 创建 Gin 实例
	r := gin.Default()
    
	// 不需要认证的公共路由
    auth := r.Group("/api/auth")
    {
        auth.POST("/login", ah.Login)
        auth.POST("/register", ah.Register)
    }
    
	// 加载模板
	r.LoadHTMLGlob("templates/*")
	
	// 静态文件服务
	r.Static("/static", "./static")
	
	// 注册路由
	registerRoutes(r)
	
    // 受保护的路由（需要 JWT 认证）
    protected := r.Group("/api/auth")
    protected.Use(handlers.JWTMiddleware())
    {
        protected.GET("/protected", handlers.ProtectedHandler) // 例如：/api/auth/protected/
        protected.POST("/logout", handlers.LogoutHandler)
    }

    dbmsadmin := &dbadmin.App{DB: db}
    protecteddbms := r.Group("/api/db")
    protecteddbms.Use(handlers.JWTMiddleware())
    {
        protecteddbms.GET("/tables", dbmsadmin.ListTables)             // list all tables
        protecteddbms.GET("/:table", dbmsadmin.ListRecords)             // list rows (pagination)
        protecteddbms.GET("/:table/:id", dbmsadmin.GetRecord)           // fetch single row by id
        protecteddbms.POST("/:table", dbmsadmin.CreateRecord)           // insert row
        protecteddbms.PUT("/:table/:id", dbmsadmin.UpdateRecord)        // update row by id
        protecteddbms.DELETE("/:table/:id", dbmsadmin.DeleteRecord)     // delete row by id
        protecteddbms.GET("/:table/count", dbmsadmin.CountRecords)
    }
	// 启动服务器
	r.Run(":8080")
}

 // VulnImpact 结构体
 type VulnImpact struct {
    Year           int
    VulnImpactType string
    VulnCount      int
}

func registerRoutes(r *gin.Engine) {
    r.GET("/", homeHandler(db))
    r.GET("/index.html", homeHandler(db))
   
    r.GET("/vulnerabilities", vulnerabilitiesHandler(db))
    r.GET("/vulnerabilities-type", vulnerabilityTypeHandler(db))
    
    
    r.GET("/cve_total_details.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "cve_total_details.html", nil) 
    })

    r.GET("/cve_high_risk_details.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "cve_high_risk_details.html", nil) 
    })

    r.GET("/cve_known_to_exploit_details.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "cve_known_to_exploit_details.html", nil) 
    })

    r.GET("/cve_bug_fixed_details.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "cve_bug_fixed_details.html", nil) 
    })

    r.GET("/vulnerabilities.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "vulnerabilities.html", nil)  // 渲染 vulnerabilities.html 页面
    })

    r.GET("/cvebyyearmonth.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "cvebyyearmonth.html", nil)  // 渲染 cvebyyearmonth.html 页面
    })

    r.GET("/vendor.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "vendor.html", nil)  // 渲染 vendor.html 页面
    })

    r.GET("/product.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "product.html", nil)  // 渲染 vendor.html 页面
    })

    r.GET("/check.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "check.html", nil)  // 渲染 vendor.html 页面
    })

    r.GET("/cve/:id", handlers.GetSimpleCveByID(db))

    r.GET("/search.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "search.html", nil)
    })

    r.GET("/search_detail.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "search_detail.html", nil)
    })

    r.GET("/permission-denied.html", func(c *gin.Context) {
        c.HTML(http.StatusOK, "permission-denied.html", nil)
    })

    r.POST("/api/cve/details", handlers.GetCVEDetails(db))

    r.GET("/cvss_score.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "cvss_score.html", nil)
    })

    r.GET("/version.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "version.html", nil)
    })

    r.GET("/version_detail.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "version_detail.html", nil)
    })

    r.GET("/cvss_score_detail.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "cvss_score_detail.html", nil)
    })

    r.GET("/vulnerabilities_details.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "vulnerabilities_details.html", nil)
    })

    r.GET("/vulnerabilities_total_details.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "vulnerabilities_total_details.html", nil)
    })

    r.GET("/vulnerabilities_type_details.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "vulnerabilities_type_details.html", nil)
    })

    r.GET("/vulnerabilities_type_total_details.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "vulnerabilities_type_total_details.html", nil)
    })

    r.GET("/vendor_vulnerabilities_details.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "vendor_vulnerabilities_details.html", nil)
    })

    r.GET("/vendor_product_details.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "vendor_product_details.html", nil)
    })

    r.GET("/product_vulnerabilities_details.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "product_vulnerabilities_details.html", nil)
    })

    r.GET("/login.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "login.html", nil)
    })

    r.GET("/register.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "register.html", nil)
    })

    r.GET("/db_admin.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "db_admin.html", nil)
    })

    r.GET("/about.html", func(c * gin.Context){
        c.HTML(http.StatusOK, "about.html", nil)
    })

    r.GET("/api/vendors", handlers.GetVendors(db))
    r.GET("/api/vendors/suggest", handlers.VendorSuggest(db))

    r.GET("/api/vendors/products/:vendor", handlers.GetVendorProducts(db))
    r.GET("/api/vendors/vulnerabilities/:vendor", handlers.GetVendorVulnerabilities(db))
    r.GET("/api/products/cveid", handlers.GetProductVulnerabilities(db))

    r.GET("/api/products", handlers.GetProducts(db))
    r.GET("/api/products/suggest", handlers.ProductSuggest(db))

    r.GET("/search_version_cve", handlers.SearchVersionCVEHandler(db))
    
    r.GET("/advanced-search", handlers.NewAdvancedSearchHandlerRaw(db))

    r.GET("/vulnerabilities_details", handlers.GetCVEIDListHandler(db))

    r.GET("/vulnerabilities_total_details", handlers.GetCVEIDsByTypeHandler(db))

    r.GET("/vulnerabilities_type_details", handlers.GetCVEIDListtypeHandler(db))

    r.GET("/vulnerabilities_type_total_details", handlers.GetCVEIDsByTypetypeHandler(db))

    

	// API 路由
	api := r.Group("/api")
    {
        api.GET("/cveids", handlers.GetCVEList(db))
        api.GET("/high_basescore_cves", handlers.NewHighBaseScoreHandler(db))
        api.GET("/cisa_due_cves", handlers.NewCISAActionDueHandler(db))
        api.GET("/bug_cves",handlers.NewBUGHandler(db))
        api.GET("/stats", getStats)
        api.GET("/type-year-stats", getTypeYearStats) //获取类型、时间、数量
        api.GET("/base-score-distribution", getBaseScoreDistribution) //获取cvss_basescore
        api.GET("/exploitability-score-distribution", getexploitabilityScoreDistribution) //获取cvss_exploitabilityscore
        api.GET("/impact-score-distribution", getimpactScoreDistribution) //获取cvss_impactscore
        api.GET("/vulnerabilites-by-type", getvulnerabilitiesbytype) //获取每个漏洞类型的数量
        api.GET("/cve", getCveByYearMonth) //获取每年每月cve的信息
        api.GET("/cvss_distribution", GetCVSSDistribution)//获取指定年月的cvss评分信息
        api.GET("/cvss_cves", getCVEsBySeverityRange) //获取cvss分数段的cveid
    }
}

// API 处理函数
func getStats(c *gin.Context) {
    var stats struct {
        Total      int64 `json:"total"`
        Critical   int64 `json:"critical"`
        Exploitable int64 `json:"exploitable"`
        Patched    int64 `json:"patched"`
    }

    // 获取 CVE 总数
    db.Table("CVEEntry").Count(&stats.Total)
    // 获取 CVE 中严重（CVSS 分数 >= 9）数量
    db.Table("Metric").Where("baseScore >= 9.0").Count(&stats.Critical)
    // 获取有 CISA 行动到期的 CVE 数量
    db.Table("CVEEntry").Where("cisaActionDue IS NOT NULL").Count(&stats.Exploitable)
    // 获取已修复的 CVE 数量
    db.Table("CVEEntry").Where("evaluatorSolution IS NOT NULL").Count(&stats.Patched)

    c.JSON(http.StatusOK, stats)
}


func getTypeYearStats(c *gin.Context) {
    var results []struct {
        Year      int    `json:"year"`
        VulnType  string `json:"vuln_type"`
        VulnCount int64  `json:"vuln_count"`
    }

    err := db.Raw(`SELECT year, vuln_type, vuln_count FROM vuln_stats_view ORDER BY year, vuln_type`).Scan(&results).Error
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, results)
}

func getvulnerabilitiesbytype(c *gin.Context) {
    // 用于接收每种类型的总数
    var results []struct {
        VulnType       string  `json:"vuln_type"`
        VulnTotalCount int64   `json:"total_count"`
        Percentage     float64 `json:"percentage"`
    }

    // 先获取总漏洞数量（排除 Other）
    var total int64
    if err := db.Raw(`
        SELECT SUM(vuln_count) 
        FROM vuln_stats_view 
        WHERE vuln_type != 'Other'
    `).Scan(&total).Error; err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to count totals: " + err.Error()})
        return
    }

    // 查询每种漏洞类型的数量（排除 Other）
    var rawResults []struct {
        VulnType       string
        VulnTotalCount int64
    }

    if err := db.Raw(`
        SELECT vuln_type, SUM(vuln_count) AS vuln_total_count
        FROM vuln_stats_view
        WHERE vuln_type != 'Other'
        GROUP BY vuln_type
        ORDER BY vuln_total_count DESC
    `).Scan(&rawResults).Error; err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Query failed: " + err.Error()})
        return
    }

    // 计算百分比并填充最终结构
    for _, r := range rawResults {
        percentage := float64(r.VulnTotalCount) * 100.0 / float64(total)
        results = append(results, struct {
            VulnType       string  `json:"vuln_type"`
            VulnTotalCount int64   `json:"total_count"`
            Percentage     float64 `json:"percentage"`
        }{
            VulnType:       r.VulnType,
            VulnTotalCount: r.VulnTotalCount,
            Percentage:     percentage,
        })
    }

    c.JSON(http.StatusOK, results)
}

// vulnerabilitiesHandler 返回一个 Gin 的处理函数
func vulnerabilitiesHandler(db *gorm.DB) func(c *gin.Context) {
    return func(c *gin.Context) {
        type ImpactCount struct {
            Year               string
            CodeExecution      int
            Bypass             int
            PrivilegeEscalation int
            DenialOfService    int
            InformationLeak    int
        }

        var results []ImpactCount
        db.Raw("SELECT * FROM vuln_impact_stats_view ORDER BY year ASC").Scan(&results)

        years := []string{}
        data := make(map[string]map[string]int)
        totals := map[string]int{
            "CodeExecution":           0,
            "Bypass":                    0,
            "PrivilegeEscalation":     0,
            "DenialOfService":         0,
            "InformationLeak":         0,
        }

        for _, row := range results {
            year := row.Year
            years = append(years, year)
            data[year] = map[string]int{
                "CodeExecution":           row.CodeExecution,
                "Bypass":                    row.Bypass,
                "PrivilegeEscalation":     row.PrivilegeEscalation,
                "DenialOfService":         row.DenialOfService,
                "InformationLeak":         row.InformationLeak,
            }

            totals["CodeExecution"] += row.CodeExecution
            totals["Bypass"] += row.Bypass
            totals["PrivilegeEscalation"] += row.PrivilegeEscalation
            totals["DenialOfService"] += row.DenialOfService
            totals["InformationLeak"] += row.InformationLeak
        }

        c.JSON(http.StatusOK, gin.H{
            "years":  years,
            "data":   data,
            "totals": totals,
        })
    }
}
func getBaseScoreDistribution(c *gin.Context) {
    // 定义用于接收查询结果的数据结构
    var results []struct {
        ScoreRange string `json:"score_range"`
        ScoreCount int64  `json:"score_count"`
    }

    // 执行 SQL 查询
    err := db.Raw(`
        SELECT '0-1' AS score_range, COUNT(*) AS score_count FROM metric WHERE baseScore >= 0 AND baseScore < 1
        UNION ALL
        SELECT '1-2', COUNT(*) FROM metric WHERE baseScore >= 1 AND baseScore < 2
        UNION ALL
        SELECT '2-3', COUNT(*) FROM metric WHERE baseScore >= 2 AND baseScore < 3
        UNION ALL
        SELECT '3-4', COUNT(*) FROM metric WHERE baseScore >= 3 AND baseScore < 4
        UNION ALL
        SELECT '4-5', COUNT(*) FROM metric WHERE baseScore >= 4 AND baseScore < 5
        UNION ALL
        SELECT '5-6', COUNT(*) FROM metric WHERE baseScore >= 5 AND baseScore < 6
        UNION ALL
        SELECT '6-7', COUNT(*) FROM metric WHERE baseScore >= 6 AND baseScore < 7
        UNION ALL
        SELECT '7-8', COUNT(*) FROM metric WHERE baseScore >= 7 AND baseScore < 8
        UNION ALL
        SELECT '8-9', COUNT(*) FROM metric WHERE baseScore >= 8 AND baseScore < 9
        UNION ALL
        SELECT '9+', COUNT(*) FROM metric WHERE baseScore >= 9
    `).Scan(&results).Error

    // 错误处理
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    // 返回 JSON 响应
    c.JSON(http.StatusOK, results)
}

func getimpactScoreDistribution(c *gin.Context) {
    // 定义用于接收查询结果的数据结构
    var results []struct {
        ScoreRange string `json:"score_range"`
        ScoreCount int64  `json:"score_count"`
    }

    // 执行 SQL 查询
    err := db.Raw(`
        SELECT '0-1' AS score_range, COUNT(*) AS score_count FROM metric WHERE impactScore >= 0 AND impactScore < 1
        UNION ALL
        SELECT '1-2', COUNT(*) FROM metric WHERE impactScore >= 1 AND impactScore < 2
        UNION ALL
        SELECT '2-3', COUNT(*) FROM metric WHERE impactScore >= 2 AND impactScore < 3
        UNION ALL
        SELECT '3-4', COUNT(*) FROM metric WHERE impactScore >= 3 AND impactScore < 4
        UNION ALL
        SELECT '4-5', COUNT(*) FROM metric WHERE impactScore >= 4 AND impactScore < 5
        UNION ALL
        SELECT '5-6', COUNT(*) FROM metric WHERE impactScore >= 5 AND impactScore < 6
        UNION ALL
        SELECT '6-7', COUNT(*) FROM metric WHERE impactScore >= 6 AND impactScore < 7
        UNION ALL
        SELECT '7-8', COUNT(*) FROM metric WHERE impactScore >= 7 AND impactScore < 8
        UNION ALL
        SELECT '8-9', COUNT(*) FROM metric WHERE impactScore >= 8 AND impactScore < 9
        UNION ALL
        SELECT '9+', COUNT(*) FROM metric WHERE impactScore >= 9
    `).Scan(&results).Error

    // 错误处理
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    // 返回 JSON 响应
    c.JSON(http.StatusOK, results)
}

func getexploitabilityScoreDistribution(c *gin.Context) {
    // 定义用于接收查询结果的数据结构
    var results []struct {
        ScoreRange string `json:"score_range"`
        ScoreCount int64  `json:"score_count"`
    }

    // 执行 SQL 查询
    err := db.Raw(`
        SELECT '0-1' AS score_range, COUNT(*) AS score_count FROM metric WHERE exploitabilityScore >= 0 AND exploitabilityScore < 1
        UNION ALL
        SELECT '1-2', COUNT(*) FROM metric WHERE exploitabilityScore >= 1 AND exploitabilityScore < 2
        UNION ALL
        SELECT '2-3', COUNT(*) FROM metric WHERE exploitabilityScore >= 2 AND exploitabilityScore < 3
        UNION ALL
        SELECT '3-4', COUNT(*) FROM metric WHERE exploitabilityScore >= 3 AND exploitabilityScore < 4
        UNION ALL
        SELECT '4-5', COUNT(*) FROM metric WHERE exploitabilityScore >= 4 AND exploitabilityScore < 5
        UNION ALL
        SELECT '5-6', COUNT(*) FROM metric WHERE exploitabilityScore >= 5 AND exploitabilityScore < 6
        UNION ALL
        SELECT '6-7', COUNT(*) FROM metric WHERE exploitabilityScore >= 6 AND exploitabilityScore < 7
        UNION ALL
        SELECT '7-8', COUNT(*) FROM metric WHERE exploitabilityScore >= 7 AND exploitabilityScore < 8
        UNION ALL
        SELECT '8-9', COUNT(*) FROM metric WHERE exploitabilityScore >= 8 AND exploitabilityScore < 9
        UNION ALL
        SELECT '9+', COUNT(*) FROM metric WHERE exploitabilityScore >= 9
    `).Scan(&results).Error

    // 错误处理
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    // 返回 JSON 响应
    c.JSON(http.StatusOK, results)
}


func GetCVSSDistribution(c *gin.Context){

    type CVSSRange struct {
        Range     string  `json:"range"`
        Count     int     `json:"count"`
        AvgScore  float64 `json:"avg_score"` // 供计算加权平均用
    }
    

    //获取日期参数
    start := c.Query("start")
    end := c.Query("end")
    
    //校验格式
    if _, err := time.Parse("2006-01-02", start); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid start date"})
        return
    }
    if _, err := time.Parse("2006-01-02", end); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid end date"})
        return
    }

    query :=
        `
    SELECT 
        r.severity_range,
        COALESCE(u.count, 0) AS count
    FROM (
        SELECT '0-1' AS severity_range
        UNION ALL SELECT '1-2'
        UNION ALL SELECT '2-3'
        UNION ALL SELECT '3-4'
        UNION ALL SELECT '4-5'
        UNION ALL SELECT '5-6'
        UNION ALL SELECT '6-7'
        UNION ALL SELECT '7-8'
        UNION ALL SELECT '8-9'
        UNION ALL SELECT '9+' 
    ) AS r
    LEFT JOIN (
        SELECT 
            CASE 
                WHEN max_score >= 9.0 THEN '9+'
                WHEN max_score >= 8.0 THEN '8-9'
                WHEN max_score >= 7.0 THEN '7-8'
                WHEN max_score >= 6.0 THEN '6-7'
                WHEN max_score >= 5.0 THEN '5-6'
                WHEN max_score >= 4.0 THEN '4-5'
                WHEN max_score >= 3.0 THEN '3-4'
                WHEN max_score >= 2.0 THEN '2-3'
                WHEN max_score >= 1.0 THEN '1-2'
                ELSE '0-1'
            END AS severity_range,
            COUNT(*) AS count
        FROM (
            SELECT 
                c.id AS cve_id,
                MAX(m.baseScore) AS max_score
            FROM 
                CVEEntry c
            JOIN 
                Metric m ON c.id = m.cve_id
            WHERE 
                c.published BETWEEN ? AND ?
            GROUP BY 
                c.id
        ) AS grouped_cves
        GROUP BY severity_range
    ) AS u ON r.severity_range = u.severity_range
    ORDER BY 
        FIELD(r.severity_range, '0-1','1-2','2-3','3-4','4-5','5-6','6-7','7-8','8-9','9+');
    `
    var result []CVSSRange
    err := db.Raw(query, start, end).Scan(&result).Error
    // 错误处理
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    // 返回 JSON 响应
    c.JSON(http.StatusOK, result)
}
// CVE 查询处理函数
func getCveByYearMonth(c *gin.Context) {
	// 从查询参数中获取年份和月份
	year := c.DefaultQuery("year", "1999") // 默认年份为1999
	month := c.DefaultQuery("month", "January") // 默认月份为January

	// 查询数据库
	var cveList []string
	err := db.Raw(`
		SELECT id
		FROM vulnerabilityyearmonth
		WHERE year = ? AND month = ?
	`, year, month).Scan(&cveList).Error

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Error querying database: " + err.Error(),})
		return
	}

	// 返回查询结果
	c.JSON(http.StatusOK, cveList)
}

type CVEIDResult struct {
    ID string
}

func getCVEsBySeverityRange(c *gin.Context) {
    severity := c.Query("range")
    start := c.Query("start")
    end := c.Query("end")

    scoreMin := 0.0
    scoreMax := 10.0

    switch severity {
    case "0-1":
        scoreMax = 1.0
    case "1-2":
        scoreMin = 1.0; scoreMax = 2.0
    case "2-3":
        scoreMin = 2.0; scoreMax = 3.0
    case "3-4":
        scoreMin = 3.0; scoreMax = 4.0
    case "4-5":
        scoreMin = 4.0; scoreMax = 5.0
    case "5-6":
        scoreMin = 5.0; scoreMax = 6.0
    case "6-7":
        scoreMin = 6.0; scoreMax = 7.0
    case "7-8":
        scoreMin = 7.0; scoreMax = 8.0
    case "8-9":
        scoreMin = 8.0; scoreMax = 9.0
    case "9+":
        scoreMin = 9.0; scoreMax = 10.0
    }

    var results []CVEIDResult

    err := db.Raw(`
        SELECT DISTINCT c.id AS id
        FROM CVEEntry c
        JOIN Metric m ON c.id = m.cve_id
        WHERE c.published BETWEEN ? AND ?
        GROUP BY c.id
        HAVING MAX(m.baseScore) >= ? AND MAX(m.baseScore) < ?
    `, start, end, scoreMin, scoreMax).Scan(&results).Error

    if err != nil {
        c.JSON(500, gin.H{"error": err.Error()})
        return
    }

    var cveIDs []string
    for _, r := range results {
        cveIDs = append(cveIDs, r.ID)
    }

    c.JSON(200, cveIDs)
}

// 定义一个可复用的处理函数
func homeHandler(db *gorm.DB) func(c *gin.Context) {
    return func(c *gin.Context) {
        // 获取统计数据
        var total, critical, exploitable, patched int64
        db.Table("CVEEntry").Count(&total)
        db.Table("Metric").Where("baseScore >= 9.0").Count(&critical)
        db.Table("CVEEntry").Where("cisaActionDue IS NOT NULL").Count(&exploitable)
        db.Table("CVEEntry").Where("evaluatorSolution IS NOT NULL").Count(&patched)

        // 获取高危漏洞列表
        var criticalCVEs []struct {
            models.CVEEntry
            models.Metric
        }

        db.Table("CVEEntry").
            Joins("JOIN Metric ON Metric.cve_id = CVEEntry.id").
            Select(`CVEEntry.id, CVEEntry.sourceIdentifier, CVEEntry.published, CVEEntry.lastModified, Metric.baseScore, CVEEntry.vulnStatus`).
            Where("Metric.baseScore >= ?", 9.0).
            Order("published DESC").
            Limit(10).
            Scan(&criticalCVEs)

        // 渲染页面
        c.HTML(http.StatusOK, "index.html", gin.H{
            "Total":         total,
            "Critical":      critical,
            "Exploitable":   exploitable,
            "Patched":       patched,
        })
    }
}

// vulnerabilityTypeHandler 返回一个 Gin 的处理函数
func vulnerabilityTypeHandler(db *gorm.DB) func(c *gin.Context) {
    return func(c *gin.Context) {
        type ImpactCount struct {
            Year               string `json:"year"`
            Overflow           int    `json:"Overflow"`
            MemoryCorruption   int    `json:"MemoryCorruption"`
            SQLInjection       int    `json:"SQLInjection"`
            XSS                int    `json:"XSS"`
            DirectoryTraversal int    `json:"DirectoryTraversal"`
            FileInclusion      int    `json:"FileInclusion"`
            CSRF               int    `json:"CSRF"`
            XXE                int    `json:"XXE"`
            SSRF               int    `json:"SSRF"`
            OpenRedirect       int    `json:"OpenRedirect"`
            InputValidation    int    `json:"InputValidation"`
        }

        var results []ImpactCount
        db.Raw("SELECT * FROM vuln_type_stats_view ORDER BY year ASC").Scan(&results)

        years := []string{}
        data := make(map[string]map[string]int)
        totals := map[string]int{
            "Overflow":           0,
            "MemoryCorruption":   0,
            "SQLInjection":       0,
            "XSS":                0,
            "DirectoryTraversal": 0,
            "FileInclusion":      0,
            "CSRF":               0,
            "XXE":                0,
            "SSRF":               0,
            "OpenRedirect":       0,
            "InputValidation":    0,
        }

        for _, row := range results {
            year := row.Year
            years = append(years, year)

            // 每年数据
            data[year] = map[string]int{
                "Overflow":           row.Overflow,
                "MemoryCorruption":   row.MemoryCorruption,
                "SQLInjection":       row.SQLInjection,
                "XSS":                row.XSS,
                "DirectoryTraversal": row.DirectoryTraversal,
                "FileInclusion":      row.FileInclusion,
                "CSRF":               row.CSRF,
                "XXE":                row.XXE,
                "SSRF":               row.SSRF,
                "OpenRedirect":       row.OpenRedirect,
                "InputValidation":    row.InputValidation,
            }

            // 累加总数
            totals["Overflow"] += row.Overflow
            totals["MemoryCorruption"] += row.MemoryCorruption
            totals["SQLInjection"] += row.SQLInjection
            totals["XSS"] += row.XSS
            totals["DirectoryTraversal"] += row.DirectoryTraversal
            totals["FileInclusion"] += row.FileInclusion
            totals["CSRF"] += row.CSRF
            totals["XXE"] += row.XXE
            totals["SSRF"] += row.SSRF
            totals["OpenRedirect"] += row.OpenRedirect
            totals["InputValidation"] += row.InputValidation
        }

        c.JSON(http.StatusOK, gin.H{
            "years":  years,
            "data":   data,
            "totals": totals,
        })
    }
}