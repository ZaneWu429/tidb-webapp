-- 清空表（如需要）
TRUNCATE TABLE ParsedVector;

-- 插入 CVSS v2 数据
INSERT INTO ParsedVector (
    cve_id, version, vectorString, AV, AC, Au, C, I, A
)
SELECT
    cve_id,
    version,
    vectorString,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 1), ':', -1) AS AV,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 2), ':', -1) AS AC,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 3), ':', -1) AS Au,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 4), ':', -1) AS C,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 5), ':', -1) AS I,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 6), ':', -1) AS A
FROM Metric
WHERE vectorString NOT LIKE 'CVSS:%';

-- 插入 CVSS v3 数据
INSERT INTO ParsedVector (
    cve_id, version, vectorString, AV, AC, PR, UI, S, C, I, A
)
SELECT
    cve_id,
    version,
    vectorString,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 2), ':', -1) AS AV,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 3), ':', -1) AS AC,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 4), ':', -1) AS PR,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 5), ':', -1) AS UI,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 6), ':', -1) AS S,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 7), ':', -1) AS C,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 8), ':', -1) AS I,
    SUBSTRING_INDEX(SUBSTRING_INDEX(vectorString, '/', 9), ':', -1) AS A
FROM Metric
WHERE vectorString LIKE 'CVSS:%';
