CREATE VIEW vuln_type_stats_view AS
SELECT 
    year,
    vuln_type,
    vuln_count
FROM 
    vuln_types_per_year
ORDER BY 
    year ASC, 
    vuln_count DESC;
