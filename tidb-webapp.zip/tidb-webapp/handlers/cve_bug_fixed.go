// /tidb-webapp/handlers/cve_bug_fixed.go
package handlers

import (
    "net/http"
    "strconv"

    "github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type CVEBugSummary struct {
    CVEID       string  `json:"id"`
    Description string  `json:"description"`
    Published   string  `json:"published"`
    BaseScore   float64 `json:"base_score"`
}

func NewBUGHandler(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        pageStr := c.DefaultQuery("page", "1")
        pageSizeStr := c.DefaultQuery("size", "20")

        page, err := strconv.Atoi(pageStr)
        if err != nil || page < 1 {
            page = 1
        }
        size, err := strconv.Atoi(pageSizeStr)
        if err != nil || size < 1 || size > 100 {
            size = 20
        }

        offset := (page - 1) * size
		// 查询总数SQL（注意只计算总数，不取数据）
        countSQL := `
			SELECT COUNT(*) 
				FROM cveentry 
				WHERE evaluatorSolution IS NOT NULL;
        `

        var total int64
        if err := db.Raw(countSQL).Scan(&total).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
            return
        }

        sqlQuery := `
        	SELECT
				c.id AS cve_id,
				COALESCE(
					(SELECT d.value FROM description d WHERE d.cve_id = c.id AND d.lang = 'en' LIMIT 1),
					''
				) AS description,
				c.published AS published,
				COALESCE(
					(SELECT m.baseScore FROM metric m WHERE m.cve_id = c.id ORDER BY baseScore DESC LIMIT 1),
					0
				) AS base_score
			FROM cveentry c
			WHERE evaluatorSolution IS NOT NULL
			ORDER BY c.id DESC
			LIMIT ? OFFSET ?;
        `

        var results []CVEBugSummary
        if err := db.Raw(sqlQuery, size, offset).Scan(&results).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
            return
        }

        c.JSON(http.StatusOK, gin.H{
            "page":     page,
            "size": 	size,
			"total": 	total,
            "data":     results,
        })
    }
}

