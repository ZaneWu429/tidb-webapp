// /tidb-webapp/handlers/cveid.go
package handlers

import (
    "net/http"
    "strconv"

    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
)

func GetCVEList(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        // 分页参数
        page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
        size, _ := strconv.Atoi(c.DefaultQuery("size", "100"))
        if page < 1 {
            page = 1
        }
        if size < 1 {
            size = 100
        }
        if size > 1000 {
            size = 1000
        }
        offset := (page - 1) * size

        // 结构体定义在函数中
        type CVEListItem struct {
            ID          string   `json:"id"`
            Published   string   `json:"published"`
            Description string   `json:"description"`
            BaseScore   *float64 `json:"baseScore"`
        }

        // 总数
        var total int64
        if err := db.Raw("SELECT COUNT(*) FROM CVEEntry").Scan(&total).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
            return
        }

        // 主查询
        var list []CVEListItem
        sql := `
            SELECT
                e.id,
                e.published,
                (SELECT d.value FROM description d WHERE d.cve_id = e.id AND d.lang = 'en' LIMIT 1) AS description,
                (SELECT m.baseScore
                 FROM metric m
                 WHERE m.cve_id = e.id
                 ORDER BY CASE m.version
                     WHEN '3.1' THEN 1
                     WHEN '3.0' THEN 2
					 WHEN '2.0' THEN 3
                     ELSE 4
                 END
                 LIMIT 1) AS baseScore
            FROM CVEEntry e
            ORDER BY e.id DESC
            LIMIT ? OFFSET ?`
        if err := db.Raw(sql, size, offset).Scan(&list).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
            return
        }

        // 返回 JSON
        c.JSON(http.StatusOK, gin.H{
            "page":  page,
            "size":  size,
            "total": total,
            "data":  list,
        })
    }
}
