INSERT INTO permissions (user_id, table_name, can_select, can_insert, can_update, can_delete)
SELECT
    1 AS user_id,
    table_name,
    TRUE AS can_select,
    TRUE AS can_insert,
    TRUE AS can_update,
    TRUE AS can_delete
FROM information_schema.tables
WHERE table_schema = 'cve_db';
