CREATE VIEW exploitability_score_distribution AS
SELECT
  SUM(CASE WHEN exploitabilityScore >= 0 AND exploitabilityScore < 1 THEN 1 ELSE 0 END) AS range_0_1,
  SUM(CASE WHEN exploitabilityScore >= 1 AND exploitabilityScore < 2 THEN 1 ELSE 0 END) AS range_1_2,
  SUM(CASE WHEN exploitabilityScore >= 2 AND exploitabilityScore < 3 THEN 1 ELSE 0 END) AS range_2_3,
  SUM(CASE WHEN exploitabilityScore >= 3 AND exploitabilityScore < 4 THEN 1 ELSE 0 END) AS range_3_4,
  SUM(CASE WHEN exploitabilityScore >= 4 AND exploitabilityScore < 5 THEN 1 ELSE 0 END) AS range_4_5,
  SUM(CASE WHEN exploitabilityScore >= 5 AND exploitabilityScore < 6 THEN 1 ELSE 0 END) AS range_5_6,
  SUM(CASE WHEN exploitabilityScore >= 6 AND exploitabilityScore < 7 THEN 1 ELSE 0 END) AS range_6_7,
  SUM(CASE WHEN exploitabilityScore >= 7 AND exploitabilityScore < 8 THEN 1 ELSE 0 END) AS range_7_8,
  SUM(CASE WHEN exploitabilityScore >= 8 AND exploitabilityScore < 9 THEN 1 ELSE 0 END) AS range_8_9,
  SUM(CASE WHEN exploitabilityScore >= 9 THEN 1 ELSE 0 END) AS range_9_10
FROM metric;