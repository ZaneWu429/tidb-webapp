// /tidb-webapp/handlers/protected.go
package handlers

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"strings"
) 

// ProtectedHandler 只有通过 JWTMiddleware 验证后才能访问
func ProtectedHandler(c *gin.Context) {
	// 从 context 里读取中间件事先放进去的字段
	userIDVal, _ := c.Get("user_id")
	emailVal,  _ := c.Get("email")
	usernameVal, _ := c.Get("username") // 新增

	// 基于安全起见再做一次存在性校验
	if userIDVal == nil || emailVal == nil {
		c.JSON(401, gin.H{"error": "unauthorized"})
		return
	}

	c.JSON(200, gin.H{
		"user_id": userIDVal,
		"email":   emailVal,
		"username": usernameVal, // 可选返回 username
		"status":  "token valid",
	})
}

// LogoutHandler 处理退出登录请求，清除 token cookie
func LogoutHandler(c *gin.Context) {
    domain := ""
    if strings.Contains(c.Request.Host, "tidb-webapp.local") {
        domain = "tidb-webapp.local"
    }
    secure := domain != ""

    // 清除 token cookie，覆盖多个常见路径
    c.SetCookie("token", "", -1, "/", domain, secure, true)
	c.SetCookie("token", "", -1, "/api/", domain, secure, true)
    c.SetCookie("token", "", -1, "/auth/", domain, secure, true)

    c.JSON(http.StatusOK, gin.H{
        "message": "已成功登出",
    })
}