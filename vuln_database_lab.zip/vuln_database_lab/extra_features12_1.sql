CREATE TABLE vuln_types_per_year (
    year INT NOT NULL,
    vuln_type VARCHAR(50) NOT NULL,
    vuln_count INT NOT NULL,
    PRIMARY KEY (year, vuln_type)
);