// /tidb-webapp/handlers/protected_test.go
package handlers

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestProtectedHandler(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name       string
		userID     interface{}
		email      interface{}
		username   interface{}
		wantStatus int
		wantBody   string
	}{
		{
			name:       "valid user info",
			userID:     "123",
			email:      "user@example.com",
			username:   "testuser",
			wantStatus: http.StatusOK,
			wantBody:   `"user_id":"123"`,
		},
		{
			name:       "missing user_id",
			userID:     nil,
			email:      "user@example.com",
			username:   "testuser",
			wantStatus: http.StatusUnauthorized,
			wantBody:   `"error":"unauthorized"`,
		},
		{
			name:       "missing email",
			userID:     "123",
			email:      nil,
			username:   "testuser",
			wantStatus: http.StatusUnauthorized,
			wantBody:   `"error":"unauthorized"`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)

			// 创建请求，GET随意即可
			c.Request, _ = http.NewRequest(http.MethodGet, "/protected", nil)

			// 设置 context key 模拟中间件放入的用户信息
			if tt.userID != nil {
				c.Set("user_id", tt.userID)
			}
			if tt.email != nil {
				c.Set("email", tt.email)
			}
			if tt.username != nil {
				c.Set("username", tt.username)
			}

			ProtectedHandler(c)

			if w.Code != tt.wantStatus {
				t.Errorf("status = %d; want %d", w.Code, tt.wantStatus)
			}
			body := w.Body.String()
			if !strings.Contains(body, tt.wantBody) {
				t.Errorf("body = %s; want to contain %s", body, tt.wantBody)
			}
		})
	}
}

func TestLogoutHandler(t *testing.T) {
	gin.SetMode(gin.TestMode)

	tests := []struct {
		name       string
		host       string
		wantStatus int
		wantCookie string
	}{
		{
			name:       "no domain",
			host:       "example.com",
			wantStatus: http.StatusOK,
			wantCookie: "token=; Path=/; HttpOnly; Max-Age=0",
		},
		{
			name:       "with tidb-webapp.local domain",
			host:       "tidb-webapp.local",
			wantStatus: http.StatusOK,
			wantCookie: "token=; Path=/; Domain=tidb-webapp.local; HttpOnly; Max-Age=0",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Request, _ = http.NewRequest(http.MethodPost, "/logout", nil)
			c.Request.Host = tt.host

			LogoutHandler(c)

			if w.Code != tt.wantStatus {
				t.Errorf("status = %d; want %d", w.Code, tt.wantStatus)
			}

			// Gin 实际设置多个cookie，测试时我们只检查第一个Set-Cookie头是否包含 token=; Path=/
			setCookies := w.HeaderMap["Set-Cookie"]
			if len(setCookies) == 0 {
				t.Errorf("expected Set-Cookie header, got none")
			} else {
				found := false
				for _, cookie := range setCookies {
					if strings.Contains(cookie, "token=;") && strings.Contains(cookie, "HttpOnly") {
						if tt.host == "tidb-webapp.local" && !strings.Contains(cookie, "Domain=tidb-webapp.local") {
							continue
						}
						found = true
						break
					}
				}
				if !found {
					t.Errorf("Set-Cookie header does not contain expected token cookie with domain. Got: %v", setCookies)
				}
			}

			// 检查响应 JSON 字符串
			if !strings.Contains(w.Body.String(), "已成功登出") {
				t.Errorf("response body does not contain '已成功登出': %s", w.Body.String())
			}
		})
	}
}
