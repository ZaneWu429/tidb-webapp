INSERT INTO permissions (
    id,
    user_id,
    table_name,
    can_select,
    can_insert,
    can_update,
    can_delete,
    created_at,
    updated_at
) VALUES (
    NULL, 60002, 'users', 1, 1, 1, 0, NOW(), NOW()
), (
    NULL, 60002, 'CVEEntry', 1, 1, 0, 0, NOW(), NOW()
), (
    NULL, 60002, 'Description', 1, 0, 0, 0, NOW(), NOW()
);