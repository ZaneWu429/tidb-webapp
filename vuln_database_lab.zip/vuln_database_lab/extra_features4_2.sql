INSERT INTO vuln_impact_types_per_year (year, vuln_impact_type, vuln_count)
SELECT 
    SUBSTRING(cve_id, 5, 4) AS year,
    CASE
        WHEN LOWER(value) REGEXP '(^|[^a-z])(arbitrary code execution|remote? code execution|rce|command injection|shell injection|kernel code execution|arbitrary kernel code)([^a-z]|$)' THEN 'CodeExecution'
        WHEN LOWER(value) REGEXP '(^|[^a-z])(bypass|security bypass|authentication bypass|protection bypass|kernel bypass|smep bypass|smap bypass|k(aslr|ptr_restrict) bypass)([^a-z]|$)' THEN 'Bypass'
        WHEN LOWER(value) REGEXP '(^|[^a-z])(privilege (escalation|elevation)|(local |kernel )?privilege escalation|lpe|(gain|obtain) (root|admin)|sudo (bug|vulnerability|bypass))([^a-z]|$)' THEN 'PrivilegeEscalation'
        WHEN LOWER(value) REGEXP '(^|[^a-z])(denial of service|dos|ddos|(kernel )?(crash|panic|oops|hang)|system crash|deadlock|resource exhaustion)([^a-z]|$)' THEN 'DenialOfService'
        WHEN LOWER(value) REGEXP '(^|[^a-z])(information (leak|disclosure)|data leak|sensitive data exposure|(kernel )?memory leak|kasan leak|uninitialized (memory|data)|(address|pointer) leak)([^a-z]|$)' THEN 'InformationLeak'
        ELSE 'Other'
    END AS vuln_impact_type,
    COUNT(*) AS vuln_count
FROM 
    description
WHERE 
    lang = 'en'
GROUP BY 
    year, vuln_impact_type;