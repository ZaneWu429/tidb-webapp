CREATE VIEW vulnerabilityyearmonth AS
SELECT
    id,
    DATE_FORMAT(published, '%Y') AS year,
    DATE_FORMAT(published, '%M') AS month
FROM CVEEntry
WHERE YEAR(published) >= 1999;