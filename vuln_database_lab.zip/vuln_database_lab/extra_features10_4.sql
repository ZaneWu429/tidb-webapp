INSERT IGNORE INTO cve_category_match (cve_id, category_id)
SELECT d.cve_id, l.category_id
FROM   description d
JOIN   category_lookup l
  ON   d.value REGEXP l.pattern
WHERE  d.lang = 'en';