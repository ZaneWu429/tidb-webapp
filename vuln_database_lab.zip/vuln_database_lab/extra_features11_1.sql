DROP TABLE IF EXISTS ParsedVector;

CREATE TABLE ParsedVector (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cve_id VARCHAR(32),
    version VARCHAR(10),
    vectorString VARCHAR(255),
    AV VARCHAR(10),
    AC VARCHAR(10),
    Au VARCHAR(10), -- 仅 v2 使用
    PR VARCHAR(10), -- 仅 v3 使用
    UI VARCHAR(10),
    S  VARCHAR(10),
    C  VARCHAR(10),
    I  VARCHAR(10),
    A  VARCHAR(10)
);
