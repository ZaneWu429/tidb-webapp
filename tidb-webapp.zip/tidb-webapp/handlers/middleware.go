// /tidb-webapp/handlers/middleware.go
package handlers

import (
    "log"
    "net/http"
    "strings"

    "github.com/gin-gonic/gin"
)

// 用于保护接口的中间件
func JWTMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        // 尝试从 Authorization Header 获取
        authHeader := c.GetHeader("Authorization")
        var tokenStr string

        if strings.HasPrefix(authHeader, "Bearer ") {
            tokenStr = strings.TrimPrefix(authHeader, "Bearer ")
            log.Printf("Token from Header: %s", tokenStr)
        } else {
            cookieToken, err := c.Cookie("token")
            if err != nil || cookieToken == "" {
                c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Missing or invalid token"})
                return
            }
            tokenStr = cookieToken
            log.Printf("Token from Cookie: %s", tokenStr)
        }

        claims, err := ParseJWT(tokenStr)
        if err != nil {
            log.Printf("JWT Parse Error: %v", err)
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Invalid token"})
            return
        }

        // 类型断言
        userIDFloat, ok := claims["user_id"].(float64)
        if !ok {
            log.Printf("Invalid user_id type in token")
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid user_id in token"})
            return
        }
        userID := uint(userIDFloat)

        email, ok := claims["email"].(string)
        if !ok {
            log.Printf("Invalid email type in token")
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid email in token"})
            return
        }
        username, ok := claims["username"].(string)
        if !ok {
            log.Printf("Invalid username type in token")
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid username in token"})
            return
        }

        // 设置上下文变量
        c.Set("username", username)
        c.Set("user_id", userID)
        c.Set("email", email)

        c.Next()
    }
}