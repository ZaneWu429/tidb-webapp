CREATE VIEW vuln_impact_stats_view AS
SELECT 
    year,
    vuln_impact_type,
    vuln_count
FROM 
    vuln_impact_types_per_year
ORDER BY 
    year ASC, 
    vuln_count DESC;
