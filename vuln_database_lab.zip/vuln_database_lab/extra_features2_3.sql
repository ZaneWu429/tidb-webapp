CREATE VIEW impact_score_distribution AS
SELECT
  SUM(CASE WHEN impactScore >= 0 AND impactScore < 1 THEN 1 ELSE 0 END) AS range_0_1,
  SUM(CASE WHEN impactScore >= 1 AND impactScore < 2 THEN 1 ELSE 0 END) AS range_1_2,
  SUM(CASE WHEN impactScore >= 2 AND impactScore < 3 THEN 1 ELSE 0 END) AS range_2_3,
  SUM(CASE WHEN impactScore >= 3 AND impactScore < 4 THEN 1 ELSE 0 END) AS range_3_4,
  SUM(CASE WHEN impactScore >= 4 AND impactScore < 5 THEN 1 ELSE 0 END) AS range_4_5,
  SUM(CASE WHEN impactScore >= 5 AND impactScore < 6 THEN 1 ELSE 0 END) AS range_5_6,
  SUM(CASE WHEN impactScore >= 6 AND impactScore < 7 THEN 1 ELSE 0 END) AS range_6_7,
  SUM(CASE WHEN impactScore >= 7 AND impactScore < 8 THEN 1 ELSE 0 END) AS range_7_8,
  SUM(CASE WHEN impactScore >= 8 AND impactScore < 9 THEN 1 ELSE 0 END) AS range_8_9,
  SUM(CASE WHEN impactScore >= 9 THEN 1 ELSE 0 END) AS range_9_10
FROM metric;
