// /tidb-webapp/handlers/presultsdisplayofcve.go
package handlers

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"time"
	"net/http"
)

type PResultsDisplayOfCVE struct {
    ID               string    `gorm:"column:id" json:"id"`
    SourceIdentifier string    `gorm:"column:sourceIdentifier" json:"sourceIdentifier"`
    Published        time.Time `gorm:"column:published" json:"published"`
    LastModified     time.Time `gorm:"column:lastModified" json:"lastModified"`
    Description      string    `gorm:"column:description" json:"description"`
    MaxScore         float64   `gorm:"column:max_score" json:"max_score"`
}

func (PResultsDisplayOfCVE) TableName() string {
    return "p_results_display_of_cve"
}

func GetCVEDetails(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        var cveIDs []string
        if err := c.BindJSON(&cveIDs); err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON"})
            return
        }

        if len(cveIDs) == 0 {
            c.JSON(http.StatusBadRequest, gin.H{"error": "Empty CVE ID list"})
            return
        }

        var results []PResultsDisplayOfCVE
        if err := db.Where("id IN ?", cveIDs).Find(&results).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": "Database query failed"})
            return
        }

        if len(results) == 0 {
            c.JSON(http.StatusNotFound, gin.H{"error": "No CVE details found"})
            return
        }

        c.JSON(http.StatusOK, results)
    }
}


