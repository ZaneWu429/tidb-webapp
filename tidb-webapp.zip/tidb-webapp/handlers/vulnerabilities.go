// /tidb-webapp/handlers/vulnerabilities.go
package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func GetCVEIDListHandler(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 获取查询参数
		yearStr := c.Query("year")
		if yearStr == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "missing year"})
			return
		}
		year, err := strconv.Atoi(yearStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid year"})
			return
		}

		vulnType := c.Query("type")
		if vulnType == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "missing type"})
			return
		}

		// 查询 CVE ID 数组
		var cveIDs []string
		sql := `
			SELECT cve_id
			FROM view_cve_vuln_summary
			WHERE year = ? AND vuln_impact_type = ?
			ORDER BY cve_id
		`
		if err := db.Raw(sql, year, vulnType).Scan(&cveIDs).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		// 返回 JSON 数组
		c.JSON(http.StatusOK, cveIDs)
	}
}

func GetCVEIDsByTypeHandler(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		vulnType := c.Query("type")
		if vulnType == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "missing type"})
			return
		}

		var cveIDs []string
		sql := `
			SELECT cve_id
			FROM view_cve_vuln_summary
			WHERE vuln_impact_type = ?
			ORDER BY cve_id
		`
		if err := db.Raw(sql, vulnType).Scan(&cveIDs).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		c.JSON(http.StatusOK, cveIDs)
	}
}



func GetCVEIDListtypeHandler(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 获取查询参数
		yearStr := c.Query("year")
		if yearStr == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "missing year"})
			return
		}
		year, err := strconv.Atoi(yearStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid year"})
			return
		}

		vulnType := c.Query("type")
		if vulnType == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "missing type"})
			return
		}

		// 查询 CVE ID 数组
		var cveIDs []string
		sql := `
			SELECT cve_id
			FROM view_cve_vuln_type_summary
			WHERE year = ? AND vuln_type = ?
			ORDER BY cve_id
		`
		if err := db.Raw(sql, year, vulnType).Scan(&cveIDs).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		// 返回 JSON 数组
		c.JSON(http.StatusOK, cveIDs)
	}
}

func GetCVEIDsByTypetypeHandler(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		vulnType := c.Query("type")
		if vulnType == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "missing type"})
			return
		}

		var cveIDs []string
		sql := `
			SELECT cve_id
			FROM view_cve_vuln_type_summary
			WHERE vuln_type = ?
			ORDER BY cve_id
		`
		if err := db.Raw(sql, vulnType).Scan(&cveIDs).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		c.JSON(http.StatusOK, cveIDs)
	}
}