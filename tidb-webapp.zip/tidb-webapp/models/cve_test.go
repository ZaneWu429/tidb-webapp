// /tidb-webapp/models/cve_test.go
package models

import (
	"testing"
	"time"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupTestDB(t *testing.T) *gorm.DB {
	// 用内存 sqlite 做测试数据库，方便快速跑测试
	db, err := gorm.Open(sqlite.Open("file::memory:?cache=shared"), &gorm.Config{})
	if err != nil {
		t.Fatalf("failed to open test db: %v", err)
	}

	err = db.AutoMigrate(
		&CVEEntry{},
		&Description{},
		&CVETag{},
		&Reference{},
		&Metric{},
		&Weakness{},
		&Configuration{},
		&VendorComment{},
		&VectorEmbedding{},
	)
	if err != nil {
		t.Fatalf("failed to migrate schema: %v", err)
	}

	return db
}

func TestCVEEntryCRUD(t *testing.T) {
	db := setupTestDB(t)

	now := time.Now()

	// 创建 CVEEntry
	entry := CVEEntry{
		ID:               "CVE-1999-0001",
		SourceIdentifier: "NVD",
		Published:        &now,
		LastModified:     &now,
		VulnStatus:       "Analyzed",
		CisaRequiredAction: "Fix",
	}

	if err := db.Create(&entry).Error; err != nil {
		t.Fatalf("failed to create CVEEntry: %v", err)
	}

	// 读取 CVEEntry
	var got CVEEntry
	if err := db.First(&got, "id = ?", "CVE-1999-0001").Error; err != nil {
		t.Fatalf("failed to query CVEEntry: %v", err)
	}

	if got.ID != entry.ID {
		t.Errorf("expected ID %s, got %s", entry.ID, got.ID)
	}

	// 更新 CVEEntry
	newStatus := "Fixed"
	if err := db.Model(&got).Update("VulnStatus", newStatus).Error; err != nil {
		t.Fatalf("failed to update CVEEntry: %v", err)
	}


	// 验证更新
	var updated CVEEntry
	if err := db.First(&updated, "id = ?", "CVE-1999-0001").Error; err != nil {
		t.Fatalf("failed to query updated CVEEntry: %v", err)
	}
	if updated.VulnStatus != newStatus {
		t.Errorf("expected VulnStatus %s, got %s", newStatus, updated.VulnStatus)
	}

	// 删除 CVEEntry
	if err := db.Delete(&CVEEntry{}, "id = ?", "CVE-1999-0001").Error; err != nil {
		t.Fatalf("failed to delete CVEEntry: %v", err)
	}

	// 确认删除
	var deleted CVEEntry
	err := db.First(&deleted, "id = ?", "CVE-1999-0001").Error
	if err == nil {
		t.Errorf("expected record to be deleted, but found")
	} else if err != gorm.ErrRecordNotFound {
		t.Fatalf("unexpected error querying deleted CVEEntry: %v", err)
	}
}
