INSERT INTO vuln_stats_per_year (year, vuln_type, vuln_count)
SELECT 
    SUBSTRING(cve_id, 5, 4) AS year,
    CASE
        WHEN LOWER(value) REGEXP 'sql injection|sqli|sql-injection|sql injection vulnerability' THEN 'SQLInjection'
        WHEN LOWER(value) REGEXP 'cross[- ]site scripting|xss' THEN 'XSS'
        WHEN LOWER(value) REGEXP 'buffer overflow|stack overflow|heap overflow|integer overflow|overflow vulnerability' THEN 'Overflow'
        WHEN LOWER(value) REGEXP 'memory corruption|use-after-free|uaf|double free|dangling pointer' THEN 'MemoryCorruption'
        WHEN LOWER(value) REGEXP 'directory traversal|path traversal|\\.\\./|dot dot slash' THEN 'DirectoryTraversal'
        WHEN LOWER(value) REGEXP 'file inclusion|local file inclusion|lfi|remote file inclusion|rfi' THEN 'FileInclusion'
        WHEN LOWER(value) REGEXP 'cross[- ]site request forgery|csrf|xsrf' THEN 'CSRF'
        WHEN LOWER(value) REGEXP 'xml external entity|xxe|xml injection' THEN 'XXE'
        WHEN LOWER(value) REGEXP 'server[- ]side request forgery|ssrf' THEN 'SSRF'
        WHEN LOWER(value) REGEXP 'open redirect|url redirection|unvalidated redirect' THEN 'OpenRedirect'
        WHEN LOWER(value) REGEXP 'input validation|improper input validation' THEN 'InputValidation'
        WHEN LOWER(value) REGEXP 'execute code|code execution|arbitrary code execution|rce' THEN 'ExecuteCode'
        WHEN LOWER(value) REGEXP 'bypass|authentication bypass|security bypass' THEN 'Bypass'
        WHEN LOWER(value) REGEXP 'gain privilege|privilege escalation|privilege elevation' THEN 'GainPrivilege'
        WHEN LOWER(value) REGEXP 'denial of service|dos|ddos|crash' THEN 'DenialOfService'
        WHEN LOWER(value) REGEXP 'information leak|information disclosure|data leak|sensitive data exposure' THEN 'InformationLeak'
        ELSE 'Other'
    END AS vuln_type,
    COUNT(*) AS vuln_count
FROM 
    description
WHERE 
    lang = 'en'
GROUP BY 
    year, vuln_type;