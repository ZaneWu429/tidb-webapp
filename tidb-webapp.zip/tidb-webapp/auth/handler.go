// /tidb-webapp/auth/handlers.go
package auth

import (
    "net/http"
    "strings"
    "time"
    "log"
    "github.com/gin-gonic/gin"
    "github.com/golang-jwt/jwt/v5"
    "golang.org/x/crypto/bcrypt"
    "gorm.io/gorm"
)

type (
    User struct {
        ID           uint
        Email        string `gorm:"size:255;not null;uniqueIndex"`
        Username     string `gorm:"size:100;not null;uniqueIndex"`
        PasswordHash []byte `gorm:"size:60;not null"`
        CreatedAt    time.Time
        UpdatedAt    time.Time
    }

    creds struct {
        Email    string `json:"email" binding:"required,email"`
        Username string `json:"username" binding:"required,min=3,max=32"`
        Password string `json:"password" binding:"required,min=5,max=72"`
    }

    authHandler struct {
        db        *gorm.DB
        jwtSecret []byte
    }
)

// 工厂：确保表存在（用纯 SQL），返回处理器
func New(db *gorm.DB, jwtSecret []byte) *authHandler {
    const ddl = `
    CREATE TABLE IF NOT EXISTS users (
        id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        email         VARCHAR(255) NOT NULL UNIQUE,
        username      VARCHAR(100) NOT NULL UNIQUE,
        password_hash VARBINARY(60) NOT NULL,
        created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    db.Exec(ddl)
    
////////////////////////////////////////////test//////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test//////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test//////////////////////////////////////////////////////////////////////
// 这里下面的一段是测试字段，专为测试设计的，在测试的时候需要取消注释，在取消掉注释的同时，需要把上面同函数名的注释掉
    // const ddl = `
    // CREATE TABLE IF NOT EXISTS users (
    //     id            INTEGER PRIMARY KEY AUTOINCREMENT,
    //     email         TEXT NOT NULL UNIQUE,
    //     username      TEXT NOT NULL UNIQUE,
    //     password_hash BLOB NOT NULL,
    //     created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    //     updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    // )`
    // db.Exec(ddl)
////////////////////////////////////////////test/////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test/////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test/////////////////////////////////////////////////////////////////////

    return &authHandler{db: db, jwtSecret: jwtSecret}
}

// POST /api/auth/register
func (h *authHandler) Register(c *gin.Context) {
    var in creds
    if err := c.ShouldBindJSON(&in); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    if h.emailExists(in.Email) {
        c.JSON(http.StatusConflict, gin.H{"error": "email already registered"})
        return
    }

    if h.usernameExists(in.Username) {
        c.JSON(http.StatusConflict, gin.H{"error": "username already taken"})
        return
    }

    hash, err := bcrypt.GenerateFromPassword([]byte(in.Password), bcrypt.DefaultCost)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "cannot hash password"})
        return
    }

    user := User{
        Email:        in.Email,
        Username:     in.Username,
        PasswordHash: hash,
    }

    if err := h.db.Create(&user).Error; err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
        return
    }

    log.Printf("[Auth] User %s registered successfully", user.Email)

    token, err := h.issueToken(user.ID, user.Email, user.Username)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Unable to generate token"})
        return
    }

    setTokenCookie(c, token)
    c.JSON(http.StatusCreated, gin.H{"token": token})
}

type loginCreds struct {
    Email    string `json:"email" binding:"required,email"`
    Password string `json:"password" binding:"required"`
}

// POST /api/auth/login
func (h *authHandler) Login(c *gin.Context) {
    var in loginCreds
    if err := c.ShouldBindJSON(&in); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    var user User
    if err := h.db.Where("email = ? OR username = ?", in.Email, in.Email).First(&user).Error; err != nil {
        log.Printf("[Auth] Failed login attempt for %s", in.Email)
        c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid email or password"})
        return
    }

    if bcrypt.CompareHashAndPassword(user.PasswordHash, []byte(in.Password)) != nil {
        log.Printf("[Auth] Failed login for %s", in.Email)
        c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid email or password"})
        return
    }

    log.Printf("[Auth] User %s logged in successfully", user.Email)

    token, err := h.issueToken(user.ID, user.Email, user.Username)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Unable to generate token"})
        return
    }

    setTokenCookie(c, token)
    c.JSON(http.StatusOK, gin.H{"token": token})
}

// 生成 JWT token
func (h *authHandler) issueToken(uid uint, email, username string) (string, error) {
    claims := jwt.MapClaims{
        "user_id": uid,
        "email":   email,
        "username": username, 
        "exp":     time.Now().Add(24 * time.Hour).Unix(),
        "iat":     time.Now().Unix(),
    }
    return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString(h.jwtSecret)
}

// 设置 Cookie
func setTokenCookie(c *gin.Context, token string) {
    domain := ""
    if strings.Contains(c.Request.Host, "tidb-webapp.local") {
        domain = "tidb-webapp.local"
    }
    secure := domain != ""

    c.SetCookie("token", token, 24*3600, "/", domain, secure, true)
}

// 检查邮箱是否已注册
func (h *authHandler) emailExists(email string) bool {
    var cnt int64
    h.db.Model(&User{}).Where("email = ?", email).Count(&cnt)
    return cnt > 0
}

func (h *authHandler) usernameExists(username string) bool {
    var cnt int64
    h.db.Model(&User{}).Where("username = ?", username).Count(&cnt)
    return cnt > 0
}


// GET /api/auth/logout
func (h *authHandler) Logout(c *gin.Context) {
    domain := ""
    if strings.Contains(c.Request.Host, "tidb-webapp.local") {
        domain = "tidb-webapp.local"
    }

    secure := domain != ""

    // 清除 token cookie
    c.SetCookie("token", "", -1, "/", domain, secure, true)
    log.Printf("[Auth] User logged out")
    c.JSON(http.StatusOK, gin.H{"message": "Successfully logged out"})
}