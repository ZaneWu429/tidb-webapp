// /tidb-webapp/models/cve.go
package models

import (
    "gorm.io/driver/mysql"
    "gorm.io/gorm"
	"time"
)


// 主表
type CVEEntry struct {
	ID                    string     `gorm:"primaryKey;column:id"`
	SourceIdentifier      string     `gorm:"column:sourceIdentifier"`
	Published             *time.Time `gorm:"column:published"`
	LastModified          *time.Time `gorm:"column:lastModified"`
	VulnStatus            string     `gorm:"column:vulnStatus"`
	EvaluatorComment      string     `gorm:"column:evaluatorComment"`
	EvaluatorImpact       string     `gorm:"column:evaluatorImpact"`
	EvaluatorSolution     string     `gorm:"column:evaluatorSolution"`
	CisaActionDue         *time.Time `gorm:"column:cisaActionDue"`
	CisaExploitAdd        *time.Time `gorm:"column:cisaExploitAdd"`
	CisaRequiredAction    string     `gorm:"column:cisaRequiredAction"`
	CisaVulnerabilityName string     `gorm:"column:cisaVulnerabilityName"`

	Descriptions    []Description    `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
	Metrics         []Metric         `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
	Tags            []CVETag         `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
	References      []Reference      `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
	Weaknesses      []Weakness       `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
	Configurations  []Configuration  `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
	VendorComments  []VendorComment  `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
	// VectorEmbedding VectorEmbedding  `gorm:"foreignKey:CVEID;references:ID;constraint:OnDelete:CASCADE"`
}

func InitDB(dsn string) (*gorm.DB, error) {
    db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
    if err != nil {
        return nil, err
    }

    // 自动迁移表结构（可选）
    db.AutoMigrate(
        &CVEEntry{},
        &Description{},
        &CVETag{},
        &Reference{},
        &Metric{},
        &Weakness{},
        &Configuration{},
        &VendorComment{},
        &VectorEmbedding{},
    )

    return db, nil
}

func (CVEEntry) TableName() string {
	return "CVEEntry"
}

// 描述
type Description struct {
	CVEID string `gorm:"column:cve_id"`
	Lang  string `gorm:"column:lang"`
	Value string `gorm:"column:value"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}

// 标签
type CVETag struct {
	CVEID            string `gorm:"column:cve_id"`
	SourceIdentifier string `gorm:"column:sourceIdentifier"`
	Tag              string `gorm:"column:tag"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}

// 参考链接
type Reference struct {
	CVEID  string `gorm:"column:cve_id"`
	URL    string `gorm:"column:url"`
	Source string `gorm:"column:source"`
	Tag    string `gorm:"column:tag"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}

// 指标信息
type Metric struct {
	CVEID               string  `gorm:"column:cve_id"`
	Version             string  `gorm:"column:version"`
	VectorString        string  `gorm:"column:vectorString"`
	BaseScore           float64 `gorm:"column:baseScore"`
	BaseSeverity        string  `gorm:"column:baseSeverity"`
	ImpactScore         float64 `gorm:"column:impactScore"`
	ExploitabilityScore float64 `gorm:"column:exploitabilityScore"`
	Source              string  `gorm:"column:source"`
	Type                string  `gorm:"column:type"`
	JSONData            string  `gorm:"column:json_data;type:json"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}

// 弱点
type Weakness struct {
	CVEID  string `gorm:"column:cve_id"`
	Source string `gorm:"column:source"`
	Type   string `gorm:"column:type"`
	Lang   string `gorm:"column:lang"`
	Value  string `gorm:"column:value"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}

// 配置信息
type Configuration struct {
	CVEID                 string `gorm:"column:cve_id"`
	Operator              string `gorm:"column:operator"`
	Negate                bool   `gorm:"column:negate"`
	MatchCriteriaID       string `gorm:"column:matchCriteriaId"`
	Criteria              string `gorm:"column:criteria"`
	Vulnerable            bool   `gorm:"column:vulnerable"`
	VersionStartIncluding string `gorm:"column:versionStartIncluding"`
	VersionEndIncluding   string `gorm:"column:versionEndIncluding"`
	VersionStartExcluding string `gorm:"column:versionStartExcluding"`
	VersionEndExcluding   string `gorm:"column:versionEndExcluding"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}

// 厂商评论
type VendorComment struct {
	CVEID        string     `gorm:"column:cve_id"`
	Organization string     `gorm:"column:organization"`
	Comment      string     `gorm:"column:comment"`
	LastModified *time.Time `gorm:"column:lastModified"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}

// 向量数据
type VectorEmbedding struct {
	CVEID    string `gorm:"primaryKey;column:cve_id"`
	Embedding []byte `gorm:"column:embedding"`

	CVE CVEEntry `gorm:"foreignKey:CVEID;references:ID"`
}
