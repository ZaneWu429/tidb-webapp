# 必须要在执行extra_features8_1.sql之前执行这个代码

import pymysql
import re

# 数据库配置
db_config = {
    "host": "127.0.0.1",
    "port": 4000,
    "user": "root",
    "password": "",
    "database": "cve_db",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.SSCursor  # 流式游标，节省内存
}

# 匹配 cpe:2.3 的格式
CPE_PATTERN = re.compile(r'^cpe:2\.3:([^:]*):([^:]*):([^:]*):([^:]*):([^:]*):([^:]*):([^:]*):([^:]*):([^:]*):([^:]*):([^:]*)$')

BATCH_SIZE = 1000

def insert_cpe_entries(connection, entries):
    with connection.cursor() as cursor:
        sql = """
            INSERT INTO cpe_entries (
                cve_id, vulnerable, part, vendor, product, version, update_version,
                edition, language, sw_edition, target_sw, target_hw, other
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.executemany(sql, entries)
    connection.commit()

def process_configurations():
    connection = pymysql.connect(**db_config)
    read_conn = pymysql.connect(**db_config)

    try:
        with read_conn.cursor() as cursor:
            cursor.execute("SELECT cve_id, criteria, vulnerable FROM configuration")

            batch = []
            total = 0
            for row in cursor:
                cve_id, criteria, vulnerable = row
                if criteria and criteria.startswith("cpe:2.3:"):
                    match = CPE_PATTERN.match(criteria)
                    if match:
                        batch.append((cve_id, vulnerable) + match.groups())

                if len(batch) >= BATCH_SIZE:
                    insert_cpe_entries(connection, batch)
                    total += len(batch)
                    print(f"Inserted {total} rows...")
                    batch.clear()

            if batch:
                insert_cpe_entries(connection, batch)
                total += len(batch)
                print(f"Inserted {total} rows.")

        print("✅ All done.")

    finally:
        connection.close()
        read_conn.close()

if __name__ == "__main__":
    process_configurations()
