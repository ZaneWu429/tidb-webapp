CREATE OR REPLACE VIEW view_cve_vuln_summary AS
SELECT
    e.id AS cve_id,
    CAST(SUBSTRING(e.id, 5, 4) AS UNSIGNED) AS year,
    CASE
        WHEN LOWER(d.value) REGEXP '(^|[^a-z])(arbitrary code execution|remote? code execution|rce|command injection|shell injection|kernel code execution|arbitrary kernel code)([^a-z]|$)'
            THEN 'CodeExecution'
        WHEN LOWER(d.value) REGEXP '(^|[^a-z])(bypass|security bypass|authentication bypass|protection bypass|kernel bypass|smep bypass|smap bypass|k(aslr|ptr_restrict) bypass)([^a-z]|$)'
            THEN 'Bypass'
        WHEN LOWER(d.value) REGEXP '(^|[^a-z])(privilege (escalation|elevation)|(local |kernel )?privilege escalation|lpe|(gain|obtain) (root|admin)|sudo (bug|vulnerability|bypass))([^a-z]|$)'
            THEN 'PrivilegeEscalation'
        WHEN LOWER(d.value) REGEXP '(^|[^a-z])(denial of service|dos|ddos|(kernel )?(crash|panic|oops|hang)|system crash|deadlock|resource exhaustion)([^a-z]|$)'
            THEN 'DenialOfService'
        WHEN LOWER(d.value) REGEXP '(^|[^a-z])(information (leak|disclosure)|data leak|sensitive data exposure|(kernel )?memory leak|kasan leak|uninitialized (memory|data)|(address|pointer) leak)([^a-z]|$)'
            THEN 'InformationLeak'
        ELSE 'Other'
    END AS vuln_impact_type
FROM
    cveentry e
JOIN
    (
        SELECT cve_id, MIN(value) AS value
        FROM description
        WHERE lang = 'en'
        GROUP BY cve_id
    ) d ON d.cve_id = e.id;
