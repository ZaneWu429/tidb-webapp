CREATE OR REPLACE VIEW vuln_impact_stats_view AS
SELECT 
    year,
    SUM(CASE WHEN vuln_impact_type = 'CodeExecution' THEN vuln_count ELSE 0 END) AS CodeExecution,
    SUM(CASE WHEN vuln_impact_type = 'Bypass' THEN vuln_count ELSE 0 END) AS Bypass,
    SUM(CASE WHEN vuln_impact_type = 'PrivilegeEscalation' THEN vuln_count ELSE 0 END) AS PrivilegeEscalation,
    SUM(CASE WHEN vuln_impact_type = 'DenialOfService' THEN vuln_count ELSE 0 END) AS DenialOfService,
    SUM(CASE WHEN vuln_impact_type = 'InformationLeak' THEN vuln_count ELSE 0 END) AS InformationLeak
FROM 
    vuln_impact_types_per_year
GROUP BY 
    year
ORDER BY 
    year ASC;
