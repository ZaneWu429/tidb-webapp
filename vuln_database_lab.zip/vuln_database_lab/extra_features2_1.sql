CREATE VIEW base_score_distribution AS
SELECT
  SUM(CASE WHEN baseScore >= 0 AND baseScore < 1 THEN 1 ELSE 0 END) AS range_0_1,
  SUM(CASE WHEN baseScore >= 1 AND baseScore < 2 THEN 1 ELSE 0 END) AS range_1_2,
  SUM(CASE WHEN baseScore >= 2 AND baseScore < 3 THEN 1 ELSE 0 END) AS range_2_3,
  SUM(CASE WHEN baseScore >= 3 AND baseScore < 4 THEN 1 ELSE 0 END) AS range_3_4,
  SUM(CASE WHEN baseScore >= 4 AND baseScore < 5 THEN 1 ELSE 0 END) AS range_4_5,
  SUM(CASE WHEN baseScore >= 5 AND baseScore < 6 THEN 1 ELSE 0 END) AS range_5_6,
  SUM(CASE WHEN baseScore >= 6 AND baseScore < 7 THEN 1 ELSE 0 END) AS range_6_7,
  SUM(CASE WHEN baseScore >= 7 AND baseScore < 8 THEN 1 ELSE 0 END) AS range_7_8,
  SUM(CASE WHEN baseScore >= 8 AND baseScore < 9 THEN 1 ELSE 0 END) AS range_8_9,
  SUM(CASE WHEN baseScore >= 9 THEN 1 ELSE 0 END) AS range_9_10
FROM metric;
