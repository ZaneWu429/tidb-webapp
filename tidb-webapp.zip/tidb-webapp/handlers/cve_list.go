// // handlers/cve_list.go
package handlers

// import (
// 	"math"
// 	"strconv"

// 	"github.com/gin-gonic/gin"
// 	"gorm.io/gorm"
// )

// type ProductCVE struct {
// 	CveID string `json:"cve_id"`
// }

// type CveListResponse struct {
// 	Cves       []ProductCVE `json:"cves"`
// 	Total      int          `json:"total"`
// 	TotalPages int          `json:"total_pages"`
// }

// // GET /api/vendors/:vendor/products/:product/cves?page=1
// func GetCvesByProduct(db *gorm.DB) gin.HandlerFunc {
// 	return func(c *gin.Context) {
// 		vendor  := c.Param("vendor")
// 		product := c.Param("product")
// 		page, _ := strconv.Atoi(c.DefaultQuery("page","1"))
// 		limit := 20
// 		offset := (page-1)*limit

// 		// 总数
// 		var total int
// 		if err := db.Raw(`
// 			SELECT COUNT(DISTINCT cve_id)
// 			FROM cpe_entries
// 			WHERE vendor = ? AND product = ?
// 		`, vendor, product).Row().Scan(&total); err != nil {
// 			c.JSON(500, gin.H{"error":"count error"})
// 			return
// 		}

// 		// 列表
// 		var cves []ProductCVE
// 		if err := db.Raw(`
// 			SELECT DISTINCT cve_id
// 			FROM cpe_entries
// 			WHERE vendor = ? AND product = ?
// 			ORDER BY cve_id
// 			LIMIT ? OFFSET ?`,
// 			vendor, product, limit, offset).Scan(&cves).Error; err != nil {
// 			c.JSON(500, gin.H{"error":"query error"})
// 			return
// 		}

// 		c.JSON(200, CveListResponse{
// 			Cves:       cves,
// 			Total:      total,
// 			TotalPages: int(math.Ceil(float64(total)/float64(limit))),
// 		})
// 	}
// }
