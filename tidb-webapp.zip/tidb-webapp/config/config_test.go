// /tidb-webapp/config/config_test.go
package config

import (
	"os"
	"testing"
)

func TestGetSecret_FromEnv(t *testing.T) {
	expected := "my-test-secret"
	os.Setenv("JWT_SECRET", expected)

	// 重新触发 getSecret()
	secret := getSecret()
	if secret != expected {
		t.Errorf("expected secret from env %q, got %q", expected, secret)
	}

	// 清除环境变量，避免影响后续测试
	os.Unsetenv("JWT_SECRET")
}

func TestGetSecret_Default(t *testing.T) {
	os.Unsetenv("JWT_SECRET") // 确保 unset

	expected := "replace-with-32-random-bytes"
	secret := getSecret()
	if secret != expected {
		t.Errorf("expected default secret %q, got %q", expected, secret)
	}
}
