UPDATE metric
SET baseSeverity = CASE
    WHEN baseScore < 4.0 THEN 'LOW'
    WHEN baseScore >= 4.0 AND baseScore < 7.0 THEN 'MEDIUM'
    WHEN baseScore >= 7.0 THEN 'HIGH'
    ELSE baseSeverity -- 保留原有值
END
WHERE baseSeverity IS NULL;