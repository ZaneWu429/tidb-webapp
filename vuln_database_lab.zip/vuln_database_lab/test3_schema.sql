-- 主表
CREATE TABLE IF NOT EXISTS CVEEntry (
    id VARCHAR(50) PRIMARY KEY,
    sourceIdentifier VARCHAR(255),
    published DATETIME,
    lastModified DATETIME,
    vulnStatus VARCHAR(50),
    evaluatorComment TEXT,
    evaluatorImpact TEXT,
    evaluatorSolution TEXT,
    cisaActionDue DATETIME,
    cisaExploitAdd DATETIME,
    cisaRequiredAction TEXT,
    cisaVulnerabilityName TEXT
);

-- 描述（多语言）
CREATE TABLE IF NOT EXISTS Description (
    cve_id VARCHAR(50),
    lang VARCHAR(10),
    value TEXT,
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);

-- 标签（每个 tag 一行）
CREATE TABLE IF NOT EXISTS CVETag (
    cve_id VARCHAR(50),
    sourceIdentifier VARCHAR(255),
    tag VARCHAR(100),
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);

-- 参考链接（每个 tag 一行）
CREATE TABLE IF NOT EXISTS Reference (
    cve_id VARCHAR(50),
    url TEXT,
    source VARCHAR(255),
    tag VARCHAR(100),
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);

-- 指标信息（每种版本、每一条记录一行）
CREATE TABLE IF NOT EXISTS Metric (
    cve_id VARCHAR(50),
    version VARCHAR(10),
    vectorString TEXT,
    baseScore FLOAT,
    baseSeverity VARCHAR(50),
    impactScore FLOAT,
    exploitabilityScore FLOAT,
    source VARCHAR(255),
    type VARCHAR(50),
    json_data JSON,
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);

-- 弱点信息（每个 description 一行）
CREATE TABLE IF NOT EXISTS Weakness (
    cve_id VARCHAR(50),
    source VARCHAR(255),
    type VARCHAR(50),
    lang VARCHAR(10),
    value TEXT,
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);

-- 配置信息（每个匹配项一行）
CREATE TABLE IF NOT EXISTS Configuration (
    cve_id VARCHAR(50),
    operator VARCHAR(20),
    negate BOOLEAN,
    matchCriteriaId VARCHAR(100),
    criteria TEXT,
    vulnerable BOOLEAN,
    versionStartIncluding TEXT,
    versionEndIncluding TEXT,
    versionStartExcluding TEXT,
    versionEndExcluding TEXT,
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);

-- 厂商评论（每条评论一行）
CREATE TABLE IF NOT EXISTS VendorComment (
    cve_id VARCHAR(50),
    organization VARCHAR(255),
    comment TEXT,
    lastModified DATETIME,
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);

-- 向量数据（预留，JSON 存储或向量索引）
CREATE TABLE IF NOT EXISTS VectorEmbedding (
    cve_id VARCHAR(50) PRIMARY KEY,
    embedding BLOB,
    FOREIGN KEY (cve_id) REFERENCES CVEEntry(id) ON DELETE CASCADE
);
