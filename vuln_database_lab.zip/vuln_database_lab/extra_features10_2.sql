/* 2. 结果表：一条 CVE 可能匹配多个类别 */
DROP TABLE IF EXISTS cve_category_match;
CREATE TABLE cve_category_match (
    cve_id       VARCHAR(40) NOT NULL,
    category_id  INT         NOT NULL,
    PRIMARY KEY (cve_id, category_id),
    KEY idx_category (category_id)
);