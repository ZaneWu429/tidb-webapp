/* 1. 漏洞类别及其正则 */
DROP TABLE IF EXISTS category_lookup;
CREATE TABLE category_lookup (
    category_id   INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(40) NOT NULL,
    pattern       VARCHAR(255) NOT NULL        -- ICU/PCRE 兼容正则
);

INSERT INTO category_lookup (category_name, pattern) VALUES
  ('Overflow',               '(?i)(stack|heap|integer)?\\s*overflow'),
  ('File Inclusion',         '(?i)file\\s+inclusion'),
  ('Create code',            '(?i)(arbitrary|remote|malicious)\\s+code\\s+(execution|injection|creation)'),
  ('Memory Corruption',      '(?i)memory\\s+corruption'),
  ('CSRF',                   '(?i)(cross[- ]site\\s+request\\s+forgery|\\bcsrf\\b)'),
  ('Bypass',                 '(?i)authentication\\s+bypass|access\\s+bypass|security\\s+bypass'),
  ('SQL Injection',          '(?i)sql\\s+injection|\\bsqli\\b'),
  ('XXE',                    '(?i)(xml\\s+external\\s+entity|\\bxxe\\b)'),
  ('Privilege escalation',   '(?i)privilege\\s+escalation|elevat(e|ion)\\s+privileges'),
  ('XSS',                    '(?i)(cross[- ]site\\s+scripting|\\bxss\\b)'),
  ('SSRF',                   '(?i)(server[- ]side\\s+request\\s+forgery|\\bssrf\\b)'),
  ('Denial of service',      '(?i)(denial[- ]of[- ]service|\\bdos\\b|\\bd\\.o\\.s\\b)'),
  ('Directory Traversal',    '(?i)(directory|path)\\s+traversal'),
  ('Open redirect',          '(?i)open\\s+redirect'),
  ('Information leak',       '(?i)information\\s+(leak|disclosure)'),
  ('Input validation',       '(?i)(improper|insufficient)\\s+input\\s+validation|unsanitized\\s+input');
  