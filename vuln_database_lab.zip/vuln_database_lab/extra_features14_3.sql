DELIMITER //
CREATE TRIGGER before_user_insert_check_username
BEFORE INSERT ON users
FOR EACH ROW
BEGIN
    IF NEW.username = 'admin' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Username "admin" is not allowed';
    END IF;
END;
//
DELIMITER ;