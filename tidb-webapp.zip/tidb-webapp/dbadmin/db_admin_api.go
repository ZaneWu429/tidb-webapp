// /tidb-webapp/dbadmin/db_admin_api.go
// Generic DB admin API with JWT‑protected routes for dynamic CRUD on any table.
// Uses GORM safely to prevent SQL injection and improve maintainability.

package dbadmin

import (
    "fmt"
    "net/http"
    "strconv"

    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
)

type App struct {
    DB *gorm.DB
}

// ---- Permission helpers ----
type permFlags struct {
    CanSelect bool
    CanInsert bool
    CanUpdate bool
    CanDelete bool
}

// 获取指定用户在某张表上的权限标志
func (a *App) getPerm(userID uint, table string) (permFlags, error) {
    var p permFlags
    err := a.DB.Table("permissions").
        Select("can_select, can_insert, can_update, can_delete").
        Where("user_id = ? AND table_name = ?", userID, table).
        Scan(&p).Error
    return p, err
}

// 快捷判断
func (p permFlags) allow(op string) bool {
    switch op {
    case "select":
        return p.CanSelect
    case "insert":
        return p.CanInsert
    case "update":
        return p.CanUpdate
    case "delete":
        return p.CanDelete
    default:
        return false
    }
}

// -------- Helpers --------
func (a *App) getUserID(c *gin.Context) (uint, bool) {
    userIDAny, ok := c.Get("user_id")
    if !ok || userIDAny == nil {
        return 0, false
    }
    return userIDAny.(uint), true
}

func parseID(c *gin.Context) (string, error) {
    id := c.Param("id")
    if id == "" {
        return "", fmt.Errorf("missing id param")
    }
    return id, nil
}

// 定义字段优先级映射表
var priorityOrderMap = map[string][]string{
    "base_score_distribution":            {"range_9_10", "range_8_9", "range_7_8"},
    "exploitability_score_distribution":  {"range_9_10", "range_8_9", "range_7_8"},
    "impact_score_distribution":          {"range_9_10", "range_8_9", "range_7_8"},
    // 添加其他特殊表
}

// 获取排序字段
func (a *App) getOrderBy(table string) string {
    var cols []string
    rows, err := a.DB.Table(table).Limit(0).Rows()
    if err != nil {
        return "id"
    }
    defer rows.Close()

    cols, _ = rows.Columns()

    // 查找优先字段
    if orderFields, ok := priorityOrderMap[table]; ok {
        for _, field := range orderFields {
            for _, col := range cols {
                if col == field {
                    return field
                }
            }
        }
    }

    // 默认查找顺序
    for _, fallback := range []string{"cve_id", "id"} {
        for _, col := range cols {
            if col == fallback {
                return fallback
            }
        }
    }

    // 最后回退到第一列
    if len(cols) > 0 {
        return cols[0]
    }

    return "id"
}

// -------- Handlers --------

// ListTables 返回数据库中所有表名（仅限有 SELECT 权限的表）
func (a *App) ListTables(c *gin.Context) {
    userID, ok := a.getUserID(c)
    if !ok {
        c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing user_id"})
        return
    }

    var tables []string
    err := a.DB.Raw("SHOW TABLES").Scan(&tables).Error
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    var allowedTables []string
    for _, t := range tables {
        p, _ := a.getPerm(userID, t)
        if p.allow("select") {
            allowedTables = append(allowedTables, t)
        }
    }

    c.JSON(http.StatusOK, allowedTables)
}

// GetRecord 查询单条记录
func (a *App) GetRecord(c *gin.Context) {
    table := c.Param("table")
    userID, ok := a.getUserID(c)
    if !ok {
        c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }

    p, _ := a.getPerm(userID, table)
    if !p.allow("select") {
        c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "permission denied"})
        return
    }

    id, err := parseID(c)
    if err != nil {
        c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    var result map[string]interface{}
    err = a.DB.Table(table).Where("id = ?", id).First(&result).Error
    if err != nil {
        if err == gorm.ErrRecordNotFound {
            c.AbortWithStatusJSON(http.StatusNotFound, gin.H{"error": "not found"})
        } else {
            c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        }
        return
    }

    c.JSON(http.StatusOK, result)
}

////////////////////////////////////////////test///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test///////////////////////////////////////////////////////////////////////////
// 这里下面的一段是测试字段，专为测试设计的，在测试的时候需要取消注释，在取消掉注释的同时，需要把上面同函数名的注释掉
// func (a *App) ListTables(c *gin.Context) {
//     userID, ok := a.getUserID(c)
//     if !ok {
//         c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing user_id"})
//         return
//     }
//     var tables []string
//     // SQLite 查询表名改成这个：
//     err := a.DB.Raw("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").Scan(&tables).Error
//     if err != nil {
//         c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
//         return
//     }
//     var allowedTables []string
//     for _, t := range tables {
//         p, _ := a.getPerm(userID, t)
//         if p.allow("select") {
//             allowedTables = append(allowedTables, t)
//         }
//     }
//     c.JSON(http.StatusOK, allowedTables)
// }

// func (a *App) GetRecord(c *gin.Context) {
//     table := c.Param("table")
//     userID, ok := a.getUserID(c)
//     if !ok {
//         c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
//         return
//     }
//     p, _ := a.getPerm(userID, table)
//     if !p.allow("select") {
//         c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "permission denied"})
//         return
//     }
//     id, err := parseID(c)
//     if err != nil {
//         c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
//         return
//     }
//     var result map[string]interface{}
//     // 用 Raw + Scan 替代 Table().Where().First()
//     err = a.DB.Raw("SELECT * FROM "+table+" WHERE id = ?", id).Scan(&result).Error
//     if err != nil {
//         if err == gorm.ErrRecordNotFound {
//             c.AbortWithStatusJSON(http.StatusNotFound, gin.H{"error": "not found"})
//         } else {
//             c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
//         }
//         return
//     }
//     c.JSON(http.StatusOK, result)
// }
////////////////////////////////////////////test///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////test///////////////////////////////////////////////////////////////////////////


// ListRecords 查询某张表的数据列表
func (a *App) ListRecords(c *gin.Context) {
    table := c.Param("table")
    userID, ok := a.getUserID(c)
    if !ok {
        c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }

    p, _ := a.getPerm(userID, table)
    if !p.allow("select") {
        c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "no select permission"})
        return
    }

    limit, _ := strconv.Atoi(c.DefaultQuery("limit", "50"))
    offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
    orderBy := a.getOrderBy(table)

    var results []map[string]interface{}
    err := a.DB.Table(table).Order(orderBy).Limit(limit).Offset(offset).Find(&results).Error
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, results)
}

// // GetRecord 查询单条记录
// func (a *App) GetRecord(c *gin.Context) {
//     table := c.Param("table")
//     userID, ok := a.getUserID(c)
//     if !ok {
//         c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
//         return
//     }

//     p, _ := a.getPerm(userID, table)
//     if !p.allow("select") {
//         c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "permission denied"})
//         return
//     }

//     id, err := parseID(c)
//     if err != nil {
//         c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
//         return
//     }

//     var result map[string]interface{}
//     err = a.DB.Table(table).Where("id = ?", id).First(&result).Error
//     if err != nil {
//         if err == gorm.ErrRecordNotFound {
//             c.AbortWithStatusJSON(http.StatusNotFound, gin.H{"error": "not found"})
//         } else {
//             c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
//         }
//         return
//     }

//     c.JSON(http.StatusOK, result)
// }

// CreateRecord 插入新记录
func (a *App) CreateRecord(c *gin.Context) {
    table := c.Param("table")
    userID, ok := a.getUserID(c)
    if !ok {
        c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }

    p, _ := a.getPerm(userID, table)
    if !p.allow("insert") {
        c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
            "error": "permission denied",
            "message": fmt.Sprintf("You do not have permission to perform the insert operation, access to table %s is denied", table),
            "redirect": "/permission-denied.html",
        })
        return
    }

    var payload map[string]interface{}
    if err := c.BindJSON(&payload); err != nil {
        c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    result := a.DB.Table(table).Create(&payload)
    if result.Error != nil {
        c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
        return
    }

    c.JSON(http.StatusCreated, gin.H{"affected": result.RowsAffected, "id": payload["id"]})
}

// UpdateRecord 更新记录
func (a *App) UpdateRecord(c *gin.Context) {
    table := c.Param("table")
    userID, ok := a.getUserID(c)
    if !ok {
        c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }

    p, _ := a.getPerm(userID, table)
    if !p.allow("update") {
        c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
            "error": "permission denied",
            "message": fmt.Sprintf("You do not have permission to perform the update operation, access to table %s is denied", table),
            "redirect": "/permission-denied.html",
        })
        return
    }

    id, err := parseID(c)
    if err != nil {
        c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    var payload map[string]interface{}
    if err := c.BindJSON(&payload); err != nil {
        c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    result := a.DB.Table(table).Where("id = ?", id).Updates(payload)
    if result.Error != nil {
        c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
        return
    }

    c.JSON(http.StatusOK, gin.H{"affected": result.RowsAffected})
}

// DeleteRecord 删除记录
func (a *App) DeleteRecord(c *gin.Context) {
    table := c.Param("table")
    userID, ok := a.getUserID(c)
    if !ok {
        c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }

    p, _ := a.getPerm(userID, table)
    if !p.allow("delete") {
        c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
            "error": "permission denied",
            "message": fmt.Sprintf("You do not have permission to perform the delete operation, access to table %s is denied", table),
            "redirect": "/permission-denied.html",
        })
        return
    }

    id, err := parseID(c)
    if err != nil {
        c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    result := a.DB.Table(table).Where("id = ?", id).Delete(nil)
    if result.Error != nil {
        c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
        return
    }

    c.JSON(http.StatusOK, gin.H{"affected": result.RowsAffected})
}

// CountRecords 获取记录总数
func (a *App) CountRecords(c *gin.Context) {
    table := c.Param("table")
    var count int64
    err := a.DB.Table(table).Count(&count).Error
    if err != nil {
        c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.JSON(http.StatusOK, gin.H{"count": count})
}
