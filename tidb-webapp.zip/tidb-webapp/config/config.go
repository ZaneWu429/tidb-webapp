// /tidb-webapp/config/config.go
package config

import "os"

var JwtSecret = []byte(getSecret())

func getSecret() string {
    secret := os.Getenv("JWT_SECRET")
    if secret == "" {
        secret = "replace-with-32-random-bytes" // 开发环境用这个
    }
    return secret
}