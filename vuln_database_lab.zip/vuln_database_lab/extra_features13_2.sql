CREATE TABLE permissions (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      BIGINT UNSIGNED NOT NULL,
    table_name   VARCHAR(64) NOT NULL,
    can_select   BOOLEAN DEFAULT FALSE,
    can_insert   BOOLEAN DEFAULT FALSE,
    can_update   BOOLEAN DEFAULT FALSE,
    can_delete   BOOLEAN DEFAULT FALSE,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_perm_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    UNIQUE KEY uk_user_table (user_id, table_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
