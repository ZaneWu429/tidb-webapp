// /tidb-webapp/auth/handlers_test.go
package auth

import (
    "bytes"
    "encoding/json"
    "net/http"
    "net/http/httptest"
    "testing"

    "github.com/gin-gonic/gin"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
)

// 创建测试环境
func setupTestHandler() *authHandler {
    db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{}) // 内存数据库
    if err != nil {
        panic("failed to connect to test db")
    }

    h := New(db, []byte("test-secret"))
    db.AutoMigrate(&User{}) // 自动创建 user 表
    return h
}

func performRequest(r http.Handler, method, path string, body any) *httptest.ResponseRecorder {
    b, _ := json.Marshal(body)
    req := httptest.NewRequest(method, path, bytes.NewBuffer(b))
    req.Header.Set("Content-Type", "application/json")

    w := httptest.NewRecorder()
    r.ServeHTTP(w, req)
    return w
}

// 测试注册接口
func TestRegister(t *testing.T) {
    h := setupTestHandler()
    gin.SetMode(gin.TestMode)
    router := gin.New()
    router.POST("/api/auth/register", h.Register)

    data := map[string]string{
        "email":    "test@example.com",
        "username": "testuser",
        "password": "123456",
    }

    w := performRequest(router, "POST", "/api/auth/register", data)
    if w.Code != http.StatusCreated {
        t.Errorf("Expected status 201 Created, got %d", w.Code)
    }
}

// 测试登录接口
func TestLogin(t *testing.T) {
    h := setupTestHandler()
    gin.SetMode(gin.TestMode)
    router := gin.New()
    router.POST("/api/auth/login", h.Login)
    router.POST("/api/auth/register", h.Register)

    // 先注册一个用户
    registerData := map[string]string{
        "email":    "login@example.com",
        "username": "loginuser",
        "password": "secret123",
    }
    performRequest(router, "POST", "/api/auth/register", registerData)

    // 正确登录
    loginData := map[string]string{
        "email":    "login@example.com",
        "password": "secret123",
    }
    w := performRequest(router, "POST", "/api/auth/login", loginData)
    if w.Code != http.StatusOK {
        t.Errorf("Expected status 200 OK, got %d", w.Code)
    }
}
