CREATE TABLE vuln_impact_types_per_year (
    year INT NOT NULL,
    vuln_impact_type VARCHAR(50) NOT NULL,
    vuln_count INT NOT NULL,
    PRIMARY KEY (year, vuln_impact_type)
);