import json
import os
from glob import glob

def extract_paths(obj, prefix="", paths_set=None):
    if paths_set is None:
        paths_set = set()
    if isinstance(obj, dict):
        for key, value in obj.items():
            path = f"{prefix}.{key}" if prefix else key
            paths_set.add(path)
            extract_paths(value, path, paths_set)
    elif isinstance(obj, list):
        for item in obj:
            extract_paths(item, prefix, paths_set)
    return paths_set

def process_json_files(directory):
    all_paths = set()
    json_files = glob(os.path.join(directory, "*.json"))
    
    print(f"Found {len(json_files)} JSON files in: {directory}")
    for json_file in json_files:
        print(f"Processing: {json_file}")
        try:
            with open(json_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            file_paths = extract_paths(data)
            all_paths.update(file_paths)
        except Exception as e:
            print(f"Error in {json_file}: {e}")
    
    return sorted(all_paths)

if __name__ == "__main__":
    directory = "./test"  # 当前目录下的 json_files 文件夹
    field_list = process_json_files(directory)

    print(f"\nExtracted {len(field_list)} unique field paths:\n")
    for field in field_list:
        print(field)

    output_path = "./all_field_paths.txt"
    with open(output_path, "w", encoding="utf-8") as out:
        for field in field_list:
            out.write(field + "\n")
    
    print(f"\nSaved to {output_path}")

