import pymysql
import json
import os
from glob import glob
from tqdm import tqdm

# --- 配置区 ---
DB_CONFIG = {
    'host': '127.0.0.1',
    'port': 4000,
    'user': 'root',
    'password': '',
    'database': 'cve_db',
    'charset': 'utf8mb4'
}
JSON_DIR = '/home/kali4redis/Desktop/vuln_database_lab/test/batch13'
BATCH_SIZE = 100
# ---------------

def connect_db():
    return pymysql.connect(**DB_CONFIG)

def is_empty(value):
    return value in [None, '', [], {}]

def insert_cve_data(cursor, cve):
    if 'id' not in cve:
        return  # 跳过没有 id 的数据

    cve_id = cve['id']

    # 主表
    cursor.execute("""
        INSERT IGNORE INTO CVEEntry (
            id, sourceIdentifier, published, lastModified, vulnStatus,
            evaluatorComment, evaluatorImpact, evaluatorSolution,
            cisaActionDue, cisaExploitAdd, cisaRequiredAction, cisaVulnerabilityName
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        cve_id,
        cve.get('sourceIdentifier'),
        cve.get('published'),
        cve.get('lastModified'),
        cve.get('vulnStatus'),
        cve.get('evaluatorComment'),
        cve.get('evaluatorImpact'),
        cve.get('evaluatorSolution'),
        cve.get('cisaActionDue'),
        cve.get('cisaExploitAdd'),
        cve.get('cisaRequiredAction'),
        cve.get('cisaVulnerabilityName')
    ))

    # 描述
    for desc in cve.get('descriptions', []):
        if not is_empty(desc.get('value')):
            cursor.execute("""
                INSERT INTO Description (cve_id, lang, value)
                VALUES (%s, %s, %s)
            """, (cve_id, desc.get('lang'), desc.get('value')))

    # 标签
    for tag_block in cve.get('cveTags', []):
        src = tag_block.get('sourceIdentifier')
        for tag in tag_block.get('tags', []):
            if not is_empty(tag):
                cursor.execute("""
                    INSERT INTO CVETag (cve_id, sourceIdentifier, tag)
                    VALUES (%s, %s, %s)
                """, (cve_id, src, tag))

    # 引用
    for ref in cve.get('references', []):
        url = ref.get('url')
        source = ref.get('source')
        for tag in ref.get('tags', []):
            if not is_empty(url):
                cursor.execute("""
                    INSERT INTO Reference (cve_id, url, source, tag)
                    VALUES (%s, %s, %s, %s)
                """, (cve_id, url, source, tag))

    # 指标
    for ver in ['cvssMetricV2', 'cvssMetricV30', 'cvssMetricV31', 'cvssMetricV40']:
        for metric in cve.get('metrics', {}).get(ver, []):
            data = metric.get('cvssData', {})
            cursor.execute("""
                INSERT INTO Metric (
                    cve_id, version, vectorString, baseScore, baseSeverity,
                    impactScore, exploitabilityScore, source, type, json_data
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                cve_id,
                data.get('version'),
                data.get('vectorString'),
                data.get('baseScore'),
                data.get('baseSeverity'),
                metric.get('impactScore'),
                metric.get('exploitabilityScore'),
                metric.get('source'),
                metric.get('type'),
                json.dumps(metric)
            ))

    # 弱点
    for w in cve.get('weaknesses', []):
        source = w.get('source')
        wtype = w.get('type')
        for desc in w.get('description', []):
            cursor.execute("""
                INSERT INTO Weakness (cve_id, source, type, lang, value)
                VALUES (%s, %s, %s, %s, %s)
            """, (cve_id, source, wtype, desc.get('lang'), desc.get('value')))

    # 配置
    for conf in cve.get('configurations', []):
        operator = conf.get('operator')
        for node in conf.get('nodes', []):
            node_operator = node.get('operator')
            negate = node.get('negate', False)
            for match in node.get('cpeMatch', []):
                cursor.execute("""
                    INSERT INTO Configuration (
                        cve_id, operator, negate, matchCriteriaId,
                        criteria, vulnerable,
                        versionStartIncluding, versionEndIncluding,
                        versionStartExcluding, versionEndExcluding
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    cve_id,
                    node_operator,
                    negate,
                    match.get('matchCriteriaId'),
                    match.get('criteria'),
                    match.get('vulnerable'),
                    match.get('versionStartIncluding'),
                    match.get('versionEndIncluding'),
                    match.get('versionStartExcluding'),
                    match.get('versionEndExcluding')
                ))

    # 厂商评论
    for vcom in cve.get('vendorComments', []):
        cursor.execute("""
            INSERT INTO VendorComment (cve_id, organization, comment, lastModified)
            VALUES (%s, %s, %s, %s)
        """, (
            cve_id,
            vcom.get('organization'),
            vcom.get('comment'),
            vcom.get('lastModified')
        ))

    # 向量嵌入（预留）
    if 'vectorEmbedding' in cve:
        vec = cve['vectorEmbedding']
        if isinstance(vec, list) and len(vec) == 384:
            cursor.execute("""
                INSERT INTO VectorEmbedding (cve_id, embedding)
                VALUES (%s, %s)
            """, (cve_id, json.dumps(vec)))

def main():
    conn = connect_db()
    cursor = conn.cursor()
    files = glob(os.path.join(JSON_DIR, "*.json"))
    total = len(files)
    print(f"[INFO] Found {total} JSON files to process.")
    count = 0

    for path in tqdm(files):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if 'cve' in data:
                insert_cve_data(cursor, data['cve'])
                count += 1
                if count % BATCH_SIZE == 0:
                    conn.commit()
        except Exception as e:
            print(f"[ERROR] File: {path} - {e}")

    conn.commit()
    cursor.close()
    conn.close()
    print(f"[DONE] Processed {count} entries.")

if __name__ == '__main__':
    main()
