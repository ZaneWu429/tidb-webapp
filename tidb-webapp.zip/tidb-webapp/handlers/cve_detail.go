// /tidb-webapp/handlers/cve_detail.go
package handlers

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"net/http"
	"strings"
	"time"
	"fmt"
)
// 定义结构体
type SimpleConfiguration struct {
	Criteria string `json:"criteria"`
}

type SimpleDescription struct {
	Value string `json:"value"`
}

type SimpleMetric struct {
	CVEID               string   `json:"cve_id"`
	Version             string   `json:"version"`
	VectorString        string   `json:"vector_string"`
	BaseScore           float64  `json:"base_score"`
	BaseSeverity        string   `json:"base_severity"`
	ImpactScore         *float64 `json:"impact_score"`
	ExploitabilityScore *float64 `json:"exploitability_score"`
	Source              string   `json:"source"`
	Type                string   `json:"type"`
}

type SimpleReference struct {
	CVEID  string `json:"cve_id"`
	URL    string `json:"url"`
	Source string `json:"source"`
	Tag    string `json:"tag"`
}

type SimpleVendorComment struct {
	CVEID        string    `json:"cve_id"`
	Organization string    `json:"organization"`
	Comment      string    `json:"comment"`
	LastModified time.Time `json:"last_modified"`
}

type SimpleWeakness struct {
	CVEID  string `json:"cve_id"`
	Source string `json:"source"`
	Type   string `json:"type"`
	Lang   string `json:"lang"`
	Value  string `json:"value"`
}

type SimpleCVEEntry struct {
	ID               string               `json:"id"`
	SourceIdentifier string               `json:"source_identifier"`
	Published        *time.Time           `json:"published"`
	LastModified     *time.Time           `json:"last_modified"`
	VulnStatus       string               `json:"vuln_status"`
	Configurations   []SimpleConfiguration `json:"configurations" gorm:"-"`
	Descriptions     []SimpleDescription   `json:"descriptions" gorm:"-"`
	Metrics          []SimpleMetric        `json:"metrics" gorm:"-"`
	References       []SimpleReference     `json:"references" gorm:"-"`
	VendorComments   []SimpleVendorComment `json:"vendor_comments" gorm:"-"`
	Weaknesses       []SimpleWeakness      `json:"weaknesses" gorm:"-"`
}

func GetSimpleCveByID(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		id := c.Param("id")
		fmt.Println("Fetching CVE with ID:", id)

		var entry SimpleCVEEntry
		err := db.Raw(`
			SELECT id, sourceIdentifier, published, lastModified, vulnStatus
			FROM cveentry
			WHERE id = ?`, id).Scan(&entry).Error
		if err != nil || entry.ID == "" {
			c.HTML(http.StatusNotFound, "cve_detail.html", gin.H{
				"error": "The CVE entry was not found",
			})
			return
		}

		// 查询 Configurations
		var configs []SimpleConfiguration
		err = db.Raw(`
			SELECT criteria
			FROM configuration
			WHERE cve_id = ?`, id).Scan(&configs).Error
		if err != nil {
			c.HTML(http.StatusNotFound, "cve_detail.html", gin.H{
				"error": "Configuration item not found",
			})
			return
		}
		entry.Configurations = configs

		// 获取描述
		var descriptions []SimpleDescription
		err = db.Raw(`
			SELECT value 
			FROM description 
			WHERE cve_id = ? AND lang = 'en'`, id).Scan(&descriptions).Error
		if err == nil {
			entry.Descriptions = descriptions
		}

		// 获取 Metrics
		var metrics []SimpleMetric
		rows, err := db.Raw(`
			SELECT cve_id, version, vectorString, baseScore, baseSeverity,
				impactScore, exploitabilityScore, source, type
			FROM metric
			WHERE cve_id = ?`, id).Rows()
		if err != nil {
			fmt.Println("Error fetching metrics:", err)
			return
		}

		defer rows.Close()
		for rows.Next() {
			var m SimpleMetric
			err := rows.Scan(&m.CVEID, &m.Version, &m.VectorString, &m.BaseScore,
				&m.BaseSeverity, &m.ImpactScore, &m.ExploitabilityScore,
				&m.Source, &m.Type)
			if err != nil {
				fmt.Println("Error scanning row:", err)
				continue
			}

			// 调试输出 version 和其他字段
			fmt.Printf("Fetched metric: version=%s, vectorString=%s, baseScore=%f\n", m.Version, m.VectorString, m.BaseScore)

			// 处理 vectorString
			if strings.HasPrefix(m.VectorString, "CVSS:") {
				if idx := strings.Index(m.VectorString, "/"); idx != -1 {
					m.VectorString = m.VectorString[idx:]
				}
			}

			// 基于 version 来确定具体的 CVSS 版本
			switch m.Version {
			case "2.0":
				fmt.Println("Detected CVSSv2")
				m.Type = "CVSSv2"
			case "3.0", "3.1":
				fmt.Println("Detected CVSSv3")
				m.Type = "CVSSv3"
			case "4.0":
				fmt.Println("Detected CVSSv4")
				m.Type = "CVSSv4"
			default:
				fmt.Println("Unknown CVSS version:", m.Version)
			}

			// 基于 baseScore 推断 baseSeverity
			if m.BaseSeverity == "" {
				switch {
				case m.BaseScore < 4.0:
					m.BaseSeverity = "LOW"
				case m.BaseScore < 7.0:
					m.BaseSeverity = "MEDIUM"
				default:
					m.BaseSeverity = "HIGH"
				}
			}

			metrics = append(metrics, m)
		}
		entry.Metrics = metrics


		// 获取 references
		var references []SimpleReference
		err = db.Raw(`
			SELECT cve_id, url, source, tag
			FROM reference
			WHERE cve_id = ?`, id).Scan(&references).Error
		if err == nil {
			entry.References = references
		}

		// 获取 vendorComments
		var vendorComments []SimpleVendorComment
		err = db.Raw(`
			SELECT cve_id, organization, comment, lastModified
			FROM vendorcomment
			WHERE cve_id = ?`, id).Scan(&vendorComments).Error
		if err == nil {
			entry.VendorComments = vendorComments
		}

		// 获取 weaknesses
		var weaknesses []SimpleWeakness
		err = db.Raw(`
			SELECT cve_id, source, type, lang, value
			FROM weakness
			WHERE cve_id = ?`, id).Scan(&weaknesses).Error
		if err == nil {
			entry.Weaknesses = weaknesses
		}

		c.HTML(http.StatusOK, "cve_detail.html", gin.H{
			"cve": entry,
		})
	}
}