// /tidb-webapp/dbadmin/db_admin_api_test.go
package dbadmin

import (
    "net/http"
    "net/http/httptest"
    "strings"
    "testing"

    "github.com/gin-gonic/gin"
    "github.com/stretchr/testify/assert"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
)

func setupTestApp() *App {
    db, _ := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
    db.Exec(`CREATE TABLE permissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        table_name TEXT,
        can_select BOOLEAN,
        can_insert BOOLEAN,
        can_update BOOLEAN,
        can_delete BOOLEAN
    )`)
    db.Exec(`CREATE TABLE test_table (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT
    )`)
    db.Exec(`INSERT INTO permissions (user_id, table_name, can_select, can_insert, can_update, can_delete)
             VALUES (1, 'test_table', true, true, false, false)`)
    return &App{DB: db}
}

func TestListTables(t *testing.T) {
    app := setupTestApp()
    router := gin.Default()
    router.GET("/tables", func(c *gin.Context) {
        c.Set("user_id", uint(1))
        app.ListTables(c)
    })

    w := httptest.NewRecorder()
    req, _ := http.NewRequest("GET", "/tables", nil)
    router.ServeHTTP(w, req)

    assert.Equal(t, http.StatusOK, w.Code)
    assert.Contains(t, w.Body.String(), "test_table")
}

func TestCreateRecord(t *testing.T) {
    app := setupTestApp()
    router := gin.Default()
    router.POST("/api/:table", func(c *gin.Context) {
        c.Set("user_id", uint(1))
        app.CreateRecord(c)
    })

    body := `{"name": "example"}`
    req := httptest.NewRequest("POST", "/api/test_table", strings.NewReader(body))
    req.Header.Set("Content-Type", "application/json")

    w := httptest.NewRecorder()
    router.ServeHTTP(w, req)

    assert.Equal(t, http.StatusCreated, w.Code)
}

func TestGetRecord(t *testing.T) {
    app := setupTestApp()
    // 预插入一条数据
    app.DB.Exec(`INSERT INTO test_table (name) VALUES ('example')`)

    router := gin.Default()
    router.GET("/api/:table/:id", func(c *gin.Context) {
        c.Set("user_id", uint(1))
        app.GetRecord(c)
    })

    w := httptest.NewRecorder()
    req, _ := http.NewRequest("GET", "/api/test_table/1", nil)
    router.ServeHTTP(w, req)

    assert.Equal(t, http.StatusOK, w.Code)
    assert.Contains(t, w.Body.String(), "example")
}
