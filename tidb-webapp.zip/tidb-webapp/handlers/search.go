// /tidb-webapp/handlers/search.go
package handlers

import (
	"fmt"
	"net/http"
	"strings"
	"time"
	"strconv"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 只用于扫描 SQL 结果（带 published 字段方便排序）
type idWithPublished struct {
	ID        string `gorm:"column:id"`
	Published string `gorm:"column:published"` // 如果是 time.Time，改成 time.Time
}

// 工厂函数，传入 *gorm.DB，返回 gin.HandlerFunc
func NewAdvancedSearchHandlerRaw(db *gorm.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		var params AdvancedSearchParams
		if err := c.ShouldBindQuery(&params); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}

		conditionSQL, args, err := buildConditionSQL(&params)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}

		dataSQL := `SELECT DISTINCT ce.id, ce.published
			FROM cveEntry ce
			LEFT JOIN metric m ON ce.id = m.cve_id
			LEFT JOIN cpe_entries cpe ON ce.id = cpe.cve_id
			LEFT JOIN weakness w ON ce.id = w.cve_id
			LEFT JOIN parsedVector v ON ce.id = v.cve_id
			LEFT JOIN cve_category_match ccm ON ce.id = ccm.cve_id
			LEFT JOIN category_lookup cl ON ccm.category_id = cl.category_id ` +
			conditionSQL +
			` ORDER BY ce.id DESC`

		var rows []idWithPublished
		if err := db.Raw(dataSQL, args...).Scan(&rows).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		// 只返回 ID 数组
		cveIDs := make([]string, 0, len(rows))
		for _, row := range rows {
			cveIDs = append(cveIDs, row.ID)
		}

		c.JSON(http.StatusOK, cveIDs)
	}
}

// 参数结构体
type AdvancedSearchParams struct {
	Vendor                string   `form:"vendor"`
	Product               string   `form:"product"`
	CweID                 string   `form:"cwe_id"`
	CvssMin               string   `form:"cvss_min"`
	CvssMax               string   `form:"cvss_max"`
	PublishStart          string   `form:"publish_date_start"`
	PublishEnd            string   `form:"publish_date_end"`
	UpdateStart           string   `form:"update_date_start"`
	UpdateEnd             string   `form:"update_date_end"`
	Categories            []int    `form:"categories"`
	AttackVector          string   `form:"attack_vector"`
	AttackComplexity      string   `form:"attack_complexity"`
	Authentication        string   `form:"authentication"`
	ConfidentialityImpact string   `form:"confidentiality_impact"`
	IntegrityImpact       string   `form:"integrity_impact"`
	AvailabilityImpact    string   `form:"availability_impact"`
}

// 构造 WHERE 条件和对应参数
func buildConditionSQL(p *AdvancedSearchParams) (string, []interface{}, error) {
	var sb strings.Builder
	var args []interface{}

	sb.WriteString("WHERE 1=1")

	if p.PublishStart != "" {
		if t, err := parseDate(p.PublishStart); err == nil {
			sb.WriteString(" AND ce.published >= ?")
			args = append(args, t)
		}
	}
	if p.PublishEnd != "" {
		if t, err := parseDate(p.PublishEnd); err == nil {
			sb.WriteString(" AND ce.published <= ?")
			args = append(args, t)
		}
	}
	if p.UpdateStart != "" {
		if t, err := parseDate(p.UpdateStart); err == nil {
			sb.WriteString(" AND ce.lastmodified >= ?")
			args = append(args, t)
		}
	}
	if p.UpdateEnd != "" {
		if t, err := parseDate(p.UpdateEnd); err == nil {
			sb.WriteString(" AND ce.lastmodified <= ?")
			args = append(args, t)
		}
	}

	if p.CvssMin != "" {
		if f, err := parseFloat(p.CvssMin); err == nil {
			sb.WriteString(" AND m.baseScore IS NOT NULL AND m.baseScore >= ?")
			args = append(args, f)
		}
	}
	if p.CvssMax != "" {
		if f, err := parseFloat(p.CvssMax); err == nil {
			sb.WriteString(" AND m.baseScore IS NOT NULL AND m.baseScore <= ?")
			args = append(args, f)
		}
	}

	if s := strings.TrimSpace(p.Vendor); s != "" {
		sb.WriteString(" AND " + buildMultiWildcardSQL("cpe.vendor", s, &args))
	}
	if s := strings.TrimSpace(p.Product); s != "" {
		sb.WriteString(" AND " + buildMultiWildcardSQL("cpe.product", s, &args))
	}

	if num := strings.TrimSpace(p.CweID); num != "" {
		sb.WriteString(" AND w.value = ?")
		args = append(args, fmt.Sprintf("CWE-%s", num))
	}

	if len(p.Categories) > 0 {
		sb.WriteString(" AND ccm.category_id IN (")
		sb.WriteString(strings.Repeat("?,", len(p.Categories)-1) + "?)")
		for _, c := range p.Categories {
			args = append(args, c)
		}
	}

	if p.AttackVector != "" {
		sb.WriteString(" AND v.AV = ?")
		args = append(args, p.AttackVector)
	}
	if p.AttackComplexity != "" {
		sb.WriteString(" AND v.AC = ?")
		args = append(args, p.AttackComplexity)
	}
	if p.Authentication != "" {
		sb.WriteString(" AND v.Au = ?")
		args = append(args, p.Authentication)
	}
	if p.ConfidentialityImpact != "" {
		sb.WriteString(" AND v.C = ?")
		args = append(args, p.ConfidentialityImpact)
	}
	if p.IntegrityImpact != "" {
		sb.WriteString(" AND v.I = ?")
		args = append(args, p.IntegrityImpact)
	}
	if p.AvailabilityImpact != "" {
		sb.WriteString(" AND v.A = ?")
		args = append(args, p.AvailabilityImpact)
	}

	return sb.String(), args, nil
}

func buildMultiWildcardSQL(col, raw string, args *[]interface{}) string {
	parts := strings.Split(raw, ",")
	var conds []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		lowerP := strings.ToLower(p)
		if strings.ContainsRune(p, '*') {
			conds = append(conds, fmt.Sprintf("LOWER(%s) LIKE ?", col))
			*args = append(*args, strings.ReplaceAll(lowerP, "*", "%"))
		} else {
			conds = append(conds, fmt.Sprintf("LOWER(%s) = ?", col))
			*args = append(*args, lowerP)
		}
	}
	return "(" + strings.Join(conds, " OR ") + ")"
}

func parseDate(s string) (string, error) {
	_, err := time.Parse("2006-01-02", s)
	if err != nil {
		return "", err
	}
	return s, nil
}

func parseFloat(s string) (float64, error) {
	return strconv.ParseFloat(s, 64)
}
