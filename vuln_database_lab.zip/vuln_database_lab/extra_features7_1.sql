CREATE VIEW p_results_display_of_cve AS
SELECT 
    c.id, 
    c.sourceIdentifier, 
    c.published, 
    c.lastModified, 
    d.value AS description, 
    m.max_score
FROM 
    CVEEntry c
JOIN 
    Description d ON c.id = d.cve_id
JOIN (
    SELECT 
        cve_id, 
        MAX(baseScore) AS max_score
    FROM 
        Metric
    GROUP BY 
        cve_id
) m ON c.id = m.cve_id
WHERE 
    d.lang = 'en';