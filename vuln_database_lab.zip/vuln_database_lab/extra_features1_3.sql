CREATE VIEW vuln_stats_view AS
SELECT 
    year,
    vuln_type,
    vuln_count
FROM 
    vuln_stats_per_year
ORDER BY 
    year ASC, 
    vuln_count DESC;
